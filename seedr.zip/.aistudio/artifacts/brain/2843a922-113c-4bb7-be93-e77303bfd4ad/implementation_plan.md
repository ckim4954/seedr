# Seedr Android — Trình Giả Lập BitTorrent Ratio & Tracker Engine Độc Lập

Chuyển đổi toàn diện mã nguồn mở `rursache/Seedr` sang ứng dụng Android gốc (Native Kotlin & Jetpack Compose), cho phép đọc tệp `.torrent`, phân tích cấu trúc Bencode, kết nối trực tiếp tới các Tracker HTTP/HTTPS và UDP (BEP-15) để báo cáo dữ liệu tải lên (Upload/Seed) giả lập theo thời gian thực ngay trên điện thoại mà không cần máy chủ trung gian hay Docker.

### User Review & Critical Decisions

> [!IMPORTANT]
> Dưới đây là các quyết định cốt lõi đã được xác nhận từ câu trả lời của bạn để đảm bảo ứng dụng hoạt động độc lập, đầy đủ tính năng nâng cao ngay trên thiết bị Android:

- **Kiến trúc chạy độc lập trên Android (Confirmed)**: Chuyển đổi toàn bộ logic xử lý phía máy chủ của `rursache/Seedr` (bộ đọc Bencode, bộ tạo thông số Client, giao thức HTTP/UDP Tracker, thuật toán phân bổ tốc độ có Jitter) sang Kotlin chạy trực tiếp trên máy Android — không cần cài đặt Docker hay máy chủ bên ngoài.
- **Đầy đủ Hồ sơ Client kèm Trình chỉnh sửa Client Profile & Hệ điều hành (Confirmed)**: Tích hợp sẵn các cấu hình chuẩn (`qBittorrent`, `Deluge`, `Transmission`, `uTorrent`, `BitTorrent`) và bổ sung **Client & OS Profile Studio** cho phép tùy chỉnh sâu từng tham số (`User-Agent`, hệ điều hành `Windows / macOS / Linux / Android`, quy tắc sinh `peer_id`, thuật toán `key`, thứ tự tham số truy vấn URL, kiểu mã hóa URL Hex).
- **Lưu trữ SQLite Room & Giám sát trực tiếp (Confirmed)**: Lưu toàn bộ danh sách Torrent, cấu hình giả lập, hồ sơ Client/OS tùy chỉnh và nhật ký sự kiện Announce (`Event Log`) vào cơ sở dữ liệu SQLite (Room) trên thiết bị, kèm bảng điều khiển theo dõi tốc độ và tỷ lệ Ratio theo thời gian thực.

---

### 1. Overview & Core Concept

- **What It Does**:
  - **Bộ giải mã `.torrent` & InfoHash gốc**: Đọc trực tiếp tệp `.torrent` từ bộ nhớ máy (hoặc tạo tệp `.torrent` mẫu để thử nghiệm nhanh), giải mã định dạng Bencode chuẩn để trích xuất chính xác mảng byte của từ điển `info`, tính toán mã băm `SHA-1 info_hash` 20-byte, danh sách Tracker (`announce` & `announce-list`), dung lượng tệp và tên Torrent.
  - **Engine Giao thức Tracker Kép (HTTP/HTTPS & UDP BEP-15)**: Thực hiện các bản tin `started`, định kỳ (`periodic`), và `stopped` tới Tracker. Tự động chuyển đổi dự phòng (failover) giữa các Tracker trong danh sách và hỗ trợ đầy đủ giao thức UDP nhị phân theo chuẩn BEP-15 (gói tin Connect 64-bit magic `0x41727101980` và gói tin Announce 98-byte).
  - **Thuật toán Mô phỏng Băng thông & Jitter**: Phân bổ tốc độ tải lên tổng thể cho các Torrent đang hoạt động theo trọng số (weighted distribution) dựa trên số lượng Leecher/Seeder, kết hợp dao động ngẫu nhiên (**Jitter**) để tốc độ biến thiên tự nhiên như mạng thật, tự động dừng khi đạt mục tiêu Ratio hoặc dung lượng Upload cấu hình.
  - **Trình chỉnh sửa Client Profile & Operating System nâng cao**: Cho phép người dùng chọn hoặc tự thiết kế hồ sơ Client và Hệ điều hành (thay đổi chuỗi định danh OS trong `User-Agent`, tiền tố `peer_id`, độ dài và tập ký tự ngẫu nhiên, định dạng `key` 8-hex/dec, chữ hoa/thường khi mã hóa phần trăm URL).
  - **Công cụ Kiểm tra Cổng Mạng (`check-host.net`)**: Tích hợp tiện ích kiểm tra khả năng kết nối cổng (Port Reachability) và chẩn đoán phản hồi Tracker trực tiếp từ trong ứng dụng.
- **Target Audience / Persona**: Người dùng muốn sử dụng đầy đủ sức mạnh của công cụ `rursache/Seedr` ngay trên chiếc điện thoại Android một cách trực quan, dễ dùng mà không cần kiến thức lập trình hay thiết lập máy chủ Docker.
- **Key Value**: Mang toàn bộ thuật toán mô phỏng giao thức chính xác của `Seedr` lên di động với giao diện bảng điều khiển thời gian thực, minh bạch từng bản tin gửi tới Tracker và kiểm soát chi tiết cấu hình Client/OS.

---

### 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Bảng điều khiển trực tiếp (Dashboard & Live Seeding)**: Hiển thị tổng băng thông Upload hiện tại (kèm biểu đồ xung nhịp trực tiếp), tổng dung lượng đã báo cáo, trạng thái Engine (Đang chạy / Tạm dừng), nút chọn nhanh hồ sơ Client + Hệ điều hành đang áp dụng, và danh sách các Torrent đang seed kèm thanh tiến trình Ratio.
  2. **Thêm & Phân tích `.torrent`**: Nhấn nút **Thêm Torrent** để chọn tệp `.torrent` từ thiết bị (hoặc nạp Torrent mẫu tích hợp sẵn để kiểm tra luồng hoạt động). Ứng dụng hiển thị ngay bản xem trước gồm tên Torrent, kích thước, mã `info_hash` (Hex), danh sách các Tracker HTTP/UDP phát hiện được và mục tiêu Ratio tùy chọn.
  3. **Trình chỉnh sửa Hồ sơ Client & Hệ điều hành (Client & OS Studio)**: Cho phép chọn từ các mẫu chuẩn (`qBittorrent 4.6.x`, `Deluge 2.1.x`, `Transmission 4.0.x`, `uTorrent 3.5.x`, `BitTorrent 7.10.x`) hoặc tạo/chỉnh sửa cấu hình nâng cao:
     - **Chỉnh sửa Operating System (OS)**: Chọn preset hệ điều hành (`Windows 10/11 x64`, `macOS Sonoma/Sequoia`, `Ubuntu/Debian Linux x86_64`, `Android 15 Mobile`, hoặc tự nhập chuỗi kernel/OS tùy ý) và xem trực tiếp chuỗi `User-Agent` cùng mẫu URL Announce được sinh ra theo thời gian thực.
     - **Chỉnh sửa thông số giao thức**: Tiền tố `peer_id` (ví dụ `-qB4650-`), thuật toán sinh `key`, thứ tự chuỗi truy vấn (`query template`), kiểu mã hóa URL (`uppercase` / `lowercase` hex) và tiêu đề HTTP bổ sung.
  4. **Nhật ký Sự kiện & Công cụ Kiểm tra Cổng (Logs & Network Tools)**: Xem nhật ký chi tiết từng lần gửi Announce (`STARTED`, `ANNOUNCE`, `STOPPED`, `FAILOVER`, `ERROR`) kèm số `Seeders/Leechers` phản hồi từ Tracker, bộ lọc theo mức độ/từ khóa, và công cụ kiểm tra cổng qua API `check-host.net`.

- **Visual Identity & Theme**:
  - *Aesthetic Direction*: **Technical Telemetry Dark** — Lấy cảm hứng từ giao diện WebUI hiện đại của `rursache/Seedr`, sử dụng nền tối sâu sắc nét kết hợp các thẻ thông số độ tương phản cao và chữ số đơn cách (monospace) cho dữ liệu mạng, hash và tốc độ.
  - *Color Palette & Mood*:
    - Nền chính (`Background` / `Surface`): Xanh đen than chì sâu (`#0B0F17` và `#131B26`) giúp nổi bật các chỉ số thời gian thực.
    - Màu nhấn chính (`Primary` — Active Seeding): Xanh lục bảo tín hiệu (`#10B981`) biểu thị trạng thái kết nối Tracker ổn định và băng thông tải lên.
    - Màu nhấn phụ (`Secondary` — Protocol & OS Studio): Xanh lam điện tử (`#38BDF8`) cho thông số Client Profile, UDP BEP-15 và cấu hình hệ điều hành.
    - Màu cảnh báo & lỗi (`Tertiary` / `Error`): Vàng hổ phách (`#F59E0B`) cho trạng thái chuyển đổi dự phòng Tracker (Failover) và Đỏ san hô (`#EF4444`) cho lỗi kết nối.
  - *Typography & Hierarchy*:
    - Tiêu đề và điều hướng: Font chữ hiện đại, rõ nét (`Space Grotesk`).
    - Thông số kỹ thuật (`info_hash`, `peer_id`, `User-Agent`, tốc độ `KB/s`, nhật ký gói tin): Font đơn cách (`JetBrains Mono`) đảm bảo các con số không bị nhảy vị trí khi cập nhật mỗi giây.
    - Nội dung văn bản: Font `Inter` dễ đọc ở mọi kích thước màn hình.
  - *Component Styling & Layout*: Hỗ trợ đầy đủ màn hình dọc và màn hình rộng (Adaptive Layout), thanh điều hướng dưới chuẩn Material 3 có tôn trọng vùng an toàn (`WindowInsets`), thẻ Torrent hiển thị trực quan tốc độ hiện tại, dung lượng đã tải lên, bộ đếm ngược tới lần Announce kế tiếp (`Next Announce in MM:SS`) và nút bật/tắt nhanh từng Torrent.
- **Interactive Feedback & Motion**: Biểu đồ tốc độ tải lên chuyển động mượt theo từng giây (Canvas), hiệu ứng xung sáng nhẹ khi ứng dụng đang gửi bản tin Announce tới Tracker, và hộp thoại xem trước trực tiếp gói tin HTTP/UDP mẫu khi người dùng chỉnh sửa Client/OS Profile.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Biên dịch toàn bộ Engine giao thức sang Kotlin gốc (Native Engine)**
  - *Chosen Approach*: Xây dựng bộ giải mã Bencode nhị phân, bộ quản lý vòng lặp Announce bằng Kotlin Coroutines, giao tiếp HTTP qua `OkHttp` (tắt `User-Agent` mặc định của hệ thống để áp dụng chính xác `User-Agent` và thứ tự Header của Client giả lập) và giao tiếp UDP BEP-15 qua `DatagramSocket` / `ByteBuffer`.
  - *Why*: Người dùng không cần kiến thức về Docker hay máy chủ từ xa; ứng dụng hoạt động 100% độc lập ngay khi mở máy và đảm bảo tính chính xác ở mức byte của `info_hash` cũng như gói tin Tracker.
  - *Alternatives Considered*: Nhúng trình duyệt WebView trỏ tới máy chủ từ xa — bị loại bỏ vì yêu cầu người dùng phải tự vận hành máy chủ riêng.
- **Decision 2: Hệ thống Client Profile & Operating System tùy biến trực quan kèm Live Preview**
  - *Chosen Approach*: Cung cấp cả kho mẫu cấu hình chuẩn của `Seedr` lẫn trình chỉnh sửa từng trường thông số (bao gồm bộ chọn và tùy biến sâu chuỗi Hệ điều hành `OS` trong HTTP Headers & định danh phiên bản), kèm khung **Live Packet Inspector** hiển thị ngay URL Announce và Header sẽ gửi đi.
  - *Why*: Giúp người dùng không chuyên vẫn có thể chọn nhanh bằng 1 chạm, đồng thời đáp ứng trọn vẹn nhu cầu tùy biến nâng cao thông số Client và Operating System.
- **Decision 3: Lưu trữ bền vững trên thiết bị bằng SQLite (Room Database)**
  - *Chosen Approach*: Sử dụng Room Database với 3 bảng dữ liệu chính (`TorrentEntity`, `ClientProfileEntity`, `EventLogEntity`) kết hợp luồng dữ liệu thời gian thực (`Flow`).
  - *Why*: Giữ nguyên kiến trúc lưu trữ SQLite của mã nguồn `rursache/Seedr` gốc, đảm bảo mọi Torrent đã nạp, tổng dung lượng đã seed, cấu hình Client/OS tùy chỉnh và lịch sử sự kiện được bảo toàn ngay cả khi đóng ứng dụng.

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:

```
┌────────────────────────────────────────────────────────────────────────────┐
│                   GIAO DIỆN NGƯỜI DÙNG (JETPACK COMPOSE)                   │
├──────────────────┬──────────────────┬──────────────────┬───────────────────┤
│  Bảng Điều Khiển │  Client & OS     │  Nhật Ký Sự Kiện │ Kiểm Tra Mạng &   │
│  & Danh Sách     │  Profile Studio  │  Announce (Logs) │ Cài Đặt Băng Thông│
│  Torrent         │  (Live Preview)  │                  │ (check-host.net)  │
└────────┬─────────┴────────┬─────────┴────────┬─────────┴─────────┬─────────┘
         │                  │                  │                   │
         ▼                  ▼                  ▼                   ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                SEEDR VIEWMODEL & STATEFLOW TELEMETRY HUB                   │
└────────┬──────────────────────────┬───────────────────────────┬────────────┘
         │                          │                           │
         ▼                          ▼                           ▼
┌──────────────────────┐ ┌──────────────────────────┐ ┌──────────────────────┐
│ BENCODE & TORRENT    │ │ SEEDR SIMULATION ENGINE  │ │ REPOSITORY & SQLITE  │
│ PARSER               │ │ (Coroutines Ticker)      │ │ (Room Database)      │
│ • Giải mã .torrent   │ │ • Phân bổ tốc độ + Jitter│ │ • TorrentEntity      │
│ • Trích xuất raw     │ │ • Sinh peer_id & key     │ │ • ClientProfileEntity│
│   info dictionary    │ │ • Bộ đếm chu kỳ Announce │ │   (kèm OS Config)    │
│ • Băm SHA-1 20-byte  │ │ • Kiểm tra mục tiêu Ratio│ │ • EventLogEntity     │
└──────────────────────┘ └──────┬─────────────┬─────┘ └──────────────────────┘
                                │             │
                   ┌────────────┘             └────────────┐
                   ▼                                       ▼
      ┌─────────────────────────┐             ┌─────────────────────────┐
      │ HTTP/HTTPS TRACKER      │             │ UDP TRACKER (BEP-15)    │
      │ ANNOUNCER (OkHttp)      │             │ ANNOUNCER (UDP Socket)  │
      │ • Thứ tự Query chuẩn    │             │ • 64-bit Magic Connect  │
      │ • Custom URL Encoding   │             │ • 98-byte Announce Pkt  │
      │ • Custom OS User-Agent  │             │ • Giải mã Seed/Leech    │
      └─────────────────────────┘             └─────────────────────────┘
```

- **Data Model & State**:
  - **Torrent Session (`TorrentEntity`)**: Lưu mã định danh, tên Torrent, mã băm `infoHashHex` (40 ký tự hex) và mảng byte gốc, tổng dung lượng (`totalSize`), danh sách URL Tracker (`trackersJson`), chỉ số Tracker đang hoạt động, tổng dữ liệu tải lên đã giả lập (`uploadedBytes`), tốc độ hiện tại (`currentSpeedBps`), số lượng `seeders` / `leechers`, chu kỳ `announceIntervalSec`, thời điểm Announce kế tiếp, trạng thái kích hoạt và mục tiêu Ratio riêng.
  - **Client & OS Profile (`ClientProfileEntity`)**: Lưu tên cấu hình, họ Client (`qBittorrent`, `Deluge`, `Transmission`, `uTorrent`, `BitTorrent`, `Custom`), phiên bản, thông tin Hệ điều hành (`osFamily`: Windows / macOS / Linux / Android / Custom, `osVersion`, `osArchitecture`), mẫu `userAgentTemplate`, tiền tố `peerIdPrefix`, độ dài và tập ký tự ngẫu nhiên của `peerId`, thuật toán sinh `key` (độ dài, hệ cơ số Hex/Dec, chữ hoa/thường), mẫu thứ tự tham số URL (`queryPattern`), quy tắc mã hóa Hex URL (`uppercaseHex`), số cổng lắng nghe giả lập (`emulatedPort`) và danh sách HTTP Headers tùy chỉnh.
  - **Announce Event Log (`EventLogEntity`)**: Lưu thời gian, loại sự kiện (`STARTED`, `PERIODIC_ANNOUNCE`, `STOPPED`, `TRACKER_FAILOVER`, `RATIO_TARGET_REACHED`, `PORT_CHECK`, `ERROR`), tên Torrent liên quan, địa chỉ Tracker, dung lượng báo cáo và chi tiết phản hồi.
  - **Global Engine Settings**: Tốc độ tải lên tối thiểu/tối đa (`minUploadRateKbps`, `maxUploadRateKbps`), tỷ lệ dao động Jitter (`jitterPercent`), mục tiêu Ratio mặc định, số lượng Torrent chạy đồng thời tối đa và trạng thái giữ màn hình/phiên chạy.

- **Interactive Component & State Mapping**:
  - **Thêm tệp `.torrent` hoặc tạo Torrent mẫu**: Khi người dùng chọn tệp `.torrent` qua trình chọn tệp hệ thống (SAF `ActivityResultContracts.GetContent`) hoặc nhấn nút nạp Torrent mẫu, `BencodeParser` đọc luồng byte, xác thực cấu trúc từ điển, tính `SHA-1` của phần `info`, hiển thị hộp thoại xác nhận thông số rồi lưu vào Room và đưa vào hàng đợi Seeding.
  - **Vòng lặp Băng thông & Announce trực tiếp**: Khi bật Engine, một bộ điều phối Coroutine cập nhật mỗi giây (`1000ms`), tính toán tốc độ tải lên có trọng số kèm nhiễu Jitter cho từng Torrent đang hoạt động, cộng dồn `uploadedBytes`, đếm ngược thời gian tới lần Announce tiếp theo và tự động kích hoạt bản tin HTTP hoặc UDP tương ứng (hoặc nút **Force Announce** để gửi bản tin ngay lập tức).
  - **Trình chỉnh sửa Client & OS Profile**: Khi người dùng thay đổi bất kỳ trường nào (ví dụ đổi Hệ điều hành từ `Windows 11 x64` sang `Linux x86_64` hoặc sửa tiền tố `peer_id`), khung xem trước ở cuối màn hình lập tức tái tạo chuỗi `peer_id` mẫu, `key` mẫu, `User-Agent` hoàn chỉnh và URL truy vấn đầy đủ để người dùng kiểm chứng trước khi lưu.
  - **Kiểm tra cổng mạng & Chẩn đoán Tracker**: Khi người dùng nhập địa chỉ IP/Host và cổng (hoặc lấy cổng giả lập hiện tại) và nhấn Kiểm tra, ứng dụng gọi API JSON của `check-host.net` để kiểm tra khả năng kết nối từ nhiều nút mạng quốc tế và hiển thị bảng kết quả trực quan.
