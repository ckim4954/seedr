package com.example

import com.example.data.SeedrDatabase
import com.example.engine.BencodeParser
import com.example.engine.ClientEmulationSpec
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun bencodeParser_extractsValidSha1InfoHashAndTrackers() {
        val raw = BencodeParser.buildSyntheticTorrentBytes(
            name = "test-archive.iso",
            sizeBytes = 104857600L,
            trackers = listOf(
                "udp://tracker.opentrackr.org:1337/announce",
                "http://tracker.opentrackr.org:1337/announce"
            )
        )
        val parsed = BencodeParser.parseTorrentFile(raw)
        assertEquals("test-archive.iso", parsed.name)
        assertEquals(104857600L, parsed.totalSize)
        assertEquals(40, parsed.infoHashHex.length)
        assertEquals(20, parsed.infoHashBytes.size)
        assertEquals(2, parsed.trackers.size)
    }

    @Test
    fun clientEmulationSpec_generatesAuthenticPeerIdAndOsUserAgent() {
        val qbProfile = SeedrDatabase.defaultClientProfiles().first()
        val peerId = ClientEmulationSpec.generatePeerId(qbProfile)
        assertEquals(20, peerId.length)
        assertTrue(peerId.startsWith("-qB4650-"))

        val customLinuxProfile = qbProfile.copy(
            osFamily = "Linux",
            customOsToken = "X11; Ubuntu; Linux x86_64; Kernel 6.8"
        )
        val userAgent = ClientEmulationSpec.buildUserAgent(customLinuxProfile)
        assertTrue(userAgent.contains("qBittorrent/4.6.5"))
        assertTrue(userAgent.contains("X11; Ubuntu; Linux x86_64; Kernel 6.8"))
    }
}
