package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianBackground = Color(0xFF0B0F17)
val SlateSurface = Color(0xFF131B26)
val SlateSurfaceElevated = Color(0xFF1A2433)
val SlateCardBorder = Color(0xFF263449)

val SignalEmerald = Color(0xFF10B981)
val SignalEmeraldDim = Color(0xFF064E3B)
val SignalEmeraldLight = Color(0xFF34D399)

val ProtocolCyan = Color(0xFF38BDF8)
val ProtocolCyanDim = Color(0xFF0C4A6E)

val FailoverAmber = Color(0xFFF59E0B)
val FailoverAmberDim = Color(0xFF78350F)

val AlertCoral = Color(0xFFEF4444)
val AlertCoralDim = Color(0xFF7F1D1D)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
