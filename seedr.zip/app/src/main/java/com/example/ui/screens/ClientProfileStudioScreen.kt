package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DeveloperBoard
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.ClientProfileEntity
import com.example.engine.ClientEmulationSpec
import com.example.ui.theme.AlertCoral
import com.example.ui.theme.FailoverAmber
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.ProtocolCyan
import com.example.ui.theme.SignalEmerald
import com.example.ui.theme.SlateCardBorder
import com.example.ui.theme.SlateSurface
import com.example.ui.theme.SlateSurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

/**
 * Màn hình Trình chỉnh sửa Hồ sơ BitTorrent Client & Hệ điều hành (Operating System Studio) nâng cao:
 * - Chuyển đổi giữa các hồ sơ chuẩn (qBittorrent, Deluge, Transmission, uTorrent, BitTorrent) hoặc tạo mới
 * - Chỉnh sửa sâu Hệ điều hành (Windows 10/11, Ubuntu/Debian Linux, macOS Sonoma/Sequoia, Android 15, FreeBSD/Custom Kernel)
 * - Chỉnh sửa thông số giao thức (peer_id prefix, charset, key format, URL hex case, query order, HTTP headers)
 * - Xem trước trực tiếp gói tin HTTP Announce & UDP BEP-15 theo thời gian thực (Live Packet Inspector)
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ClientProfileStudioScreen(
    profiles: List<ClientProfileEntity>,
    selectedProfile: ClientProfileEntity?,
    onSelectProfile: (ClientProfileEntity) -> Unit,
    onSaveProfile: (ClientProfileEntity) -> Unit,
    onDeleteCustomProfile: (ClientProfileEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val active = selectedProfile ?: profiles.firstOrNull()

    var editingId by rememberSaveable { mutableStateOf(0L) }
    var name by rememberSaveable { mutableStateOf("") }
    var clientFamily by rememberSaveable { mutableStateOf("qBittorrent") }
    var clientVersion by rememberSaveable { mutableStateOf("4.6.5") }
    var osFamily by rememberSaveable { mutableStateOf("Windows") }
    var osVersion by rememberSaveable { mutableStateOf("Windows NT 10.0") }
    var osArch by rememberSaveable { mutableStateOf("Win64; x64") }
    var customOsToken by rememberSaveable { mutableStateOf("Windows NT 10.0; Win64; x64") }
    var userAgentTemplate by rememberSaveable { mutableStateOf("qBittorrent/{version} ({os_token})") }
    var peerIdPrefix by rememberSaveable { mutableStateOf("-qB4650-") }
    var peerIdCharset by rememberSaveable { mutableStateOf("URL_SAFE_ASCII") }
    var peerIdUrlEncodeAll by rememberSaveable { mutableStateOf(false) }
    var keyLength by rememberSaveable { mutableIntStateOf(8) }
    var keyFormat by rememberSaveable { mutableStateOf("HEX_UPPER") }
    var urlHexCase by rememberSaveable { mutableStateOf("LOWER") }
    var emulatedPortText by rememberSaveable { mutableStateOf("54832") }
    var numWantText by rememberSaveable { mutableStateOf("200") }
    var queryTemplate by rememberSaveable {
        mutableStateOf("info_hash={info_hash}&peer_id={peer_id}&port={port}&uploaded={uploaded}&downloaded={downloaded}&left={left}&corrupt=0&key={key}{event_param}&numwant={numwant}&compact=1&no_peer_id=1&supportcrypto=1&redundant=0")
    }
    var customHeadersCsv by rememberSaveable { mutableStateOf("Accept-Encoding: gzip\nConnection: close") }
    var isBuiltIn by rememberSaveable { mutableStateOf(true) }

    LaunchedEffect(active?.id) {
        if (active != null) {
            editingId = active.id
            name = active.name
            clientFamily = active.clientFamily
            clientVersion = active.clientVersion
            osFamily = active.osFamily
            osVersion = active.osVersion
            osArch = active.osArch
            customOsToken = active.customOsToken
            userAgentTemplate = active.userAgentTemplate
            peerIdPrefix = active.peerIdPrefix
            peerIdCharset = active.peerIdCharset
            peerIdUrlEncodeAll = active.peerIdUrlEncodeAll
            keyLength = active.keyLength
            keyFormat = active.keyFormat
            urlHexCase = active.urlHexCase
            emulatedPortText = active.emulatedPort.toString()
            numWantText = active.numWant.toString()
            queryTemplate = active.queryTemplate
            customHeadersCsv = active.customHeadersCsv
            isBuiltIn = active.isBuiltIn
        }
    }

    val draftProfile = remember(
        editingId, name, clientFamily, clientVersion, osFamily, osVersion, osArch,
        customOsToken, userAgentTemplate, peerIdPrefix, peerIdCharset, peerIdUrlEncodeAll,
        keyLength, keyFormat, urlHexCase, emulatedPortText, numWantText, queryTemplate, customHeadersCsv, isBuiltIn
    ) {
        ClientProfileEntity(
            id = editingId,
            name = name.ifBlank { "$clientFamily $clientVersion ($osFamily)" },
            clientFamily = clientFamily,
            clientVersion = clientVersion,
            osFamily = osFamily,
            osVersion = osVersion,
            osArch = osArch,
            customOsToken = customOsToken,
            userAgentTemplate = userAgentTemplate,
            peerIdPrefix = peerIdPrefix,
            peerIdRandomLength = (20 - peerIdPrefix.length).coerceAtLeast(0),
            peerIdCharset = peerIdCharset,
            peerIdUrlEncodeAll = peerIdUrlEncodeAll,
            keyLength = keyLength,
            keyFormat = keyFormat,
            urlHexCase = urlHexCase,
            numWant = numWantText.toIntOrNull()?.coerceIn(10, 500) ?: 200,
            emulatedPort = emulatedPortText.toIntOrNull()?.coerceIn(1024, 65535) ?: 51413,
            queryTemplate = queryTemplate,
            customHeadersCsv = customHeadersCsv,
            isSelected = true,
            isBuiltIn = isBuiltIn
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .testTag("client_profile_studio_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Bộ chọn nhanh Hồ sơ Client có sẵn & Tạo mới
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "HỒ SƠ CLIENT & HỆ ĐIỀU HÀNH (${profiles.size})",
                        style = MaterialTheme.typography.labelLarge,
                        color = TextSecondary
                    )
                    OutlinedButton(
                        onClick = {
                            editingId = 0L
                            isBuiltIn = false
                            name = "Custom $clientFamily ($osFamily)"
                        },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("new_custom_profile_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Nhân bản / Tạo mới", style = MaterialTheme.typography.labelSmall)
                    }
                }

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(profiles, key = { it.id }) { item ->
                        val isSelected = item.id == active?.id && editingId != 0L
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .border(
                                    width = 1.dp,
                                    color = if (isSelected) SignalEmerald else SlateCardBorder,
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable { onSelectProfile(item) }
                                .testTag("profile_chip_${item.id}"),
                            color = if (isSelected) SignalEmerald.copy(alpha = 0.16f) else SlateSurface
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = if (isSelected) Icons.Default.CheckCircle else Icons.Default.Computer,
                                    contentDescription = null,
                                    tint = if (isSelected) SignalEmerald else ProtocolCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                                Column {
                                    Text(
                                        text = item.name,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = if (isSelected) SignalEmerald else MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "${item.peerIdPrefix} • OS: ${item.osFamily}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 2. TRÌNH CHỈNH SỬA HỆ ĐIỀU HÀNH (OPERATING SYSTEM EDITOR)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ProtocolCyan.copy(alpha = 0.4f), RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SlateSurface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeveloperBoard,
                            contentDescription = null,
                            tint = ProtocolCyan
                        )
                        Column {
                            Text(
                                text = "TRÌNH CHỈNH SỬA OPERATING SYSTEM (OS)",
                                style = MaterialTheme.typography.titleMedium,
                                color = ProtocolCyan,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Tùy biến nền tảng Hệ điều hành, phiên bản Kernel và kiến trúc CPU báo cáo lên Tracker",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }
                    }

                    // Chọn nhanh họ Hệ điều hành (OS Family)
                    Text(
                        text = "Họ Hệ điều hành (OS Family):",
                        style = MaterialTheme.typography.labelLarge
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("Windows", "Linux", "macOS", "Android", "Custom").forEach { family ->
                            val selected = osFamily.equals(family, ignoreCase = true)
                            FilterChip(
                                selected = selected,
                                onClick = {
                                    osFamily = family
                                    val preset = ClientEmulationSpec.osPresets.firstOrNull {
                                        it.osFamily.equals(family, ignoreCase = true)
                                    }
                                    if (preset != null) {
                                        osVersion = preset.osVersion
                                        osArch = preset.osArch
                                        customOsToken = preset.osToken
                                    }
                                },
                                label = { Text(family) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ProtocolCyan.copy(alpha = 0.22f),
                                    selectedLabelColor = ProtocolCyan
                                ),
                                modifier = Modifier.testTag("os_family_chip_$family")
                            )
                        }
                    }

                    // Các mẫu Preset Hệ điều hành chi tiết
                    Text(
                        text = "Mẫu cấu hình OS / Kernel chuẩn (Chạm để nạp):",
                        style = MaterialTheme.typography.labelLarge
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ClientEmulationSpec.osPresets.forEach { preset ->
                            val isCurrentPreset = customOsToken == preset.osToken
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(
                                        width = 1.dp,
                                        color = if (isCurrentPreset) SignalEmerald else SlateCardBorder,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .clickable {
                                        osFamily = preset.osFamily
                                        osVersion = preset.osVersion
                                        osArch = preset.osArch
                                        customOsToken = preset.osToken
                                    },
                                color = if (isCurrentPreset) SignalEmerald.copy(alpha = 0.15f) else SlateSurfaceElevated
                            ) {
                                Text(
                                    text = preset.label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isCurrentPreset) SignalEmerald else TextSecondary,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = osVersion,
                            onValueChange = {
                                osVersion = it
                                customOsToken = "$it; $osArch".trim(' ', ';')
                            },
                            label = { Text("Phiên bản OS (OS Version)") },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("os_version_input")
                        )
                        OutlinedTextField(
                            value = osArch,
                            onValueChange = {
                                osArch = it
                                customOsToken = "$osVersion; $it".trim(' ', ';')
                            },
                            label = { Text("Kiến trúc CPU (Arch)") },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("os_arch_input")
                        )
                    }

                    OutlinedTextField(
                        value = customOsToken,
                        onValueChange = { customOsToken = it },
                        label = { Text("Chuỗi định danh Hệ điều hành đầy đủ ({os_token} trong User-Agent)") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("custom_os_token_input")
                    )
                }
            }
        }

        // 3. TRÌNH CHỈNH SỬA THÔNG SỐ CLIENT PROFILE NÂNG CAO
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SlateCardBorder, RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SlateSurface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Code,
                            contentDescription = null,
                            tint = SignalEmerald
                        )
                        Column {
                            Text(
                                text = "THÔNG SỐ BITTORRENT CLIENT NÂNG CAO",
                                style = MaterialTheme.typography.titleMedium,
                                color = SignalEmerald,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Tùy chỉnh Peer ID, thuật toán Key, mã hóa Hex URL và thứ tự tham số truy vấn",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }
                    }

                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Tên Hồ sơ (Profile Name)") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("profile_name_input")
                    )

                    // Chọn nhanh họ BitTorrent Client
                    Text(
                        text = "Họ BitTorrent Client:",
                        style = MaterialTheme.typography.labelLarge
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("qBittorrent", "Deluge", "Transmission", "uTorrent", "BitTorrent", "Custom").forEach { fam ->
                            FilterChip(
                                selected = clientFamily.equals(fam, ignoreCase = true),
                                onClick = { clientFamily = fam },
                                label = { Text(fam) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = SignalEmerald.copy(alpha = 0.2f),
                                    selectedLabelColor = SignalEmerald
                                )
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = clientVersion,
                            onValueChange = { clientVersion = it },
                            label = { Text("Phiên bản Client") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = peerIdPrefix,
                            onValueChange = { peerIdPrefix = it.take(12) },
                            label = { Text("Tiền tố peer_id (VD: -qB4650-)") },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("peer_id_prefix_input")
                        )
                    }

                    OutlinedTextField(
                        value = userAgentTemplate,
                        onValueChange = { userAgentTemplate = it },
                        label = { Text("Mẫu HTTP User-Agent (hỗ trợ {version}, {os_token})") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Bảng mã sinh ngẫu nhiên Peer ID & Định dạng Key
                    Text(
                        text = "Tập ký tự ngẫu nhiên của peer_id (20 bytes):",
                        style = MaterialTheme.typography.labelLarge
                    )
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("URL_SAFE_ASCII", "ALPHANUMERIC", "HEX_LOWER", "HEX_UPPER").forEach { cs ->
                            FilterChip(
                                selected = peerIdCharset == cs,
                                onClick = { peerIdCharset = cs },
                                label = { Text(cs) }
                            )
                        }
                    }

                    Text(
                        text = "Thuật toán sinh Key phiên (8 ký tự) & Kiểu mã hóa URL Hex (%XX):",
                        style = MaterialTheme.typography.labelLarge
                    )
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("HEX_UPPER", "HEX_LOWER", "DECIMAL", "ALPHANUMERIC").forEach { kf ->
                            FilterChip(
                                selected = keyFormat == kf,
                                onClick = { keyFormat = kf },
                                label = { Text("Key: $kf") }
                            )
                        }
                        listOf("UPPER", "LOWER").forEach { hexCase ->
                            FilterChip(
                                selected = urlHexCase == hexCase,
                                onClick = { urlHexCase = hexCase },
                                label = { Text(if (hexCase == "UPPER") "URL %2F (Hoa)" else "URL %2f (Thường)") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = FailoverAmber.copy(alpha = 0.22f),
                                    selectedLabelColor = FailoverAmber
                                )
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = emulatedPortText,
                            onValueChange = { emulatedPortText = it },
                            label = { Text("Cổng lắng nghe (Port)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = numWantText,
                            onValueChange = { numWantText = it },
                            label = { Text("Số Peer yêu cầu (numwant)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Mã hóa phần trăm toàn bộ 20 byte của peer_id",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Switch(
                            checked = peerIdUrlEncodeAll,
                            onCheckedChange = { peerIdUrlEncodeAll = it }
                        )
                    }

                    OutlinedTextField(
                        value = queryTemplate,
                        onValueChange = { queryTemplate = it },
                        label = { Text("Mẫu thứ tự tham số URL Announce (Query String Pattern)") },
                        minLines = 2,
                        maxLines = 4,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = customHeadersCsv,
                        onValueChange = { customHeadersCsv = it },
                        label = { Text("HTTP Headers bổ sung (mỗi dòng: Header: Value)") },
                        minLines = 2,
                        maxLines = 4,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Nút Lưu cấu hình hoặc Lưu thành bản mới
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { onSaveProfile(draftProfile) },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("save_profile_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = SignalEmerald,
                                contentColor = Color(0xFF042F2E)
                            )
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (editingId == 0L) "Tạo & Áp dụng Hồ sơ" else "Lưu & Áp dụng thay đổi",
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (!isBuiltIn && editingId != 0L) {
                            IconButton(
                                onClick = { onDeleteCustomProfile(draftProfile) },
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(AlertCoral.copy(alpha = 0.16f))
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = "Xóa hồ sơ tùy chỉnh",
                                    tint = AlertCoral
                                )
                            }
                        }
                    }
                }
            }
        }

        // 4. LIVE PACKET & ANNOUNCE INSPECTOR (XEM TRƯỚC GÓI TIN THỜI GIAN THỰC)
        item {
            LivePacketInspectorCard(profile = draftProfile)
        }
    }
}

@Composable
private fun LivePacketInspectorCard(profile: ClientProfileEntity) {
    val samplePeerId = remember(profile.peerIdPrefix, profile.peerIdCharset) {
        ClientEmulationSpec.generatePeerId(profile)
    }
    val sampleKey = remember(profile.keyLength, profile.keyFormat) {
        ClientEmulationSpec.generateSessionKey(profile)
    }
    val resolvedUserAgent = remember(profile) {
        ClientEmulationSpec.buildUserAgent(profile)
    }
    val sampleAnnounceUrl = remember(profile, samplePeerId, sampleKey) {
        ClientEmulationSpec.buildAnnounceUrl(
            baseTrackerUrl = "https://tracker.opentrackr.org:443/announce",
            profile = profile,
            infoHashHex = "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3",
            peerId = samplePeerId,
            key = sampleKey,
            uploaded = 2_147_483_648L,
            downloaded = 0L,
            left = 0L,
            event = "started"
        )
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SlateCardBorder, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SlateSurfaceElevated)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Terminal,
                    contentDescription = null,
                    tint = FailoverAmber
                )
                Text(
                    text = "LIVE PACKET INSPECTOR (XEM TRƯỚC BẢN TIN GỬI TRACKER)",
                    style = MaterialTheme.typography.labelLarge,
                    color = FailoverAmber
                )
            }

            Surface(
                color = ObsidianBackground,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "User-Agent: $resolvedUserAgent",
                        style = MaterialTheme.typography.labelSmall,
                        color = SignalEmerald
                    )
                    Text(
                        text = "OS Token: ${ClientEmulationSpec.resolveOsToken(profile)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = ProtocolCyan
                    )
                    Text(
                        text = "Sample peer_id (20B): $samplePeerId   |   Session key: $sampleKey",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                    HorizontalDivider(color = SlateCardBorder)
                    Text(
                        text = "HTTP Request Preview:",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                    Text(
                        text = "GET $sampleAnnounceUrl HTTP/1.1",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                    HorizontalDivider(color = SlateCardBorder)
                    Text(
                        text = "UDP BEP-15 Binary Frame (98 Bytes Big-Endian):",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                    Text(
                        text = "Magic=0x0000041727101980 | Action=0x00000001 (Announce) | Port=${profile.emulatedPort} | NumWant=${profile.numWant}",
                        style = MaterialTheme.typography.labelSmall,
                        color = ProtocolCyan
                    )
                }
            }
        }
    }
}
