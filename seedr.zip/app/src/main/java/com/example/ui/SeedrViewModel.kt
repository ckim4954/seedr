package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ClientProfileEntity
import com.example.data.EventLogEntity
import com.example.data.GlobalEngineSettings
import com.example.data.SeedrDatabase
import com.example.data.SeedrRepository
import com.example.data.TorrentEntity
import com.example.engine.BencodeParser
import com.example.engine.ClientEmulationSpec
import com.example.engine.ParsedTorrentMeta
import com.example.engine.PortCheckReport
import com.example.engine.PortCheckerService
import com.example.engine.TrackerAnnouncer
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.random.Random

data class SeedrDashboardState(
    val isEngineRunning: Boolean = false,
    val totalUploadSpeedBps: Long = 0L,
    val sessionUploadedBytes: Long = 0L,
    val speedHistoryKbps: List<Float> = List(36) { 0f },
    val nowEpochSec: Long = System.currentTimeMillis() / 1000L,
    val statusBannerMessage: String? = null,
    val isCheckingPort: Boolean = false,
    val lastPortReport: PortCheckReport? = null,
    val pendingParsedTorrent: ParsedTorrentMeta? = null
)

class SeedrViewModel(application: Application) : AndroidViewModel(application) {

    private val database = SeedrDatabase.getInstance(application)
    private val repository = SeedrRepository(application, database.seedrDao())
    private val trackerAnnouncer = TrackerAnnouncer()
    private val portChecker = PortCheckerService()

    val torrents: StateFlow<List<TorrentEntity>> = repository.torrentsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val profiles: StateFlow<List<ClientProfileEntity>> = repository.profilesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedProfile: StateFlow<ClientProfileEntity?> = repository.selectedProfileFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val eventLogs: StateFlow<List<EventLogEntity>> = repository.recentLogsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val globalSettings: StateFlow<GlobalEngineSettings> = repository.globalSettingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), GlobalEngineSettings())

    private val _dashboardState = MutableStateFlow(SeedrDashboardState())
    val dashboardState: StateFlow<SeedrDashboardState> = _dashboardState.asStateFlow()

    private var engineTickerJob: Job? = null

    init {
        viewModelScope.launch {
            repository.ensureSeedDataInitialized()
            // Tự động khởi động Engine mô phỏng ngay khi mở ứng dụng để người dùng thấy dữ liệu trực tiếp
            startEngine()
        }
    }

    fun toggleEngine() {
        if (_dashboardState.value.isEngineRunning) {
            stopEngine()
        } else {
            startEngine()
        }
    }

    fun startEngine() {
        if (engineTickerJob?.isActive == true) return
        _dashboardState.value = _dashboardState.value.copy(
            isEngineRunning = true,
            statusBannerMessage = "Đã kích hoạt Engine giả lập Tracker (HTTP & UDP BEP-15)"
        )

        viewModelScope.launch {
            val profile = repository.getSelectedProfileOnce()
            val all = repository.getAllTorrentsOnce()
            val nowSec = System.currentTimeMillis() / 1000L
            for (t in all.filter { it.isActive }) {
                val peerId = t.sessionPeerId.takeIf { it.length == 20 }
                    ?: ClientEmulationSpec.generatePeerId(profile)
                val key = t.sessionKey.takeIf { it.isNotBlank() }
                    ?: ClientEmulationSpec.generateSessionKey(profile)
                val nextAnnounce = if (t.nextAnnounceEpochSec <= nowSec) {
                    nowSec + t.announceIntervalSec.coerceAtLeast(300)
                } else {
                    t.nextAnnounceEpochSec
                }
                repository.updateTorrent(
                    t.copy(
                        sessionPeerId = peerId,
                        sessionKey = key,
                        nextAnnounceEpochSec = nextAnnounce
                    )
                )
            }
            repository.logEvent(
                EventLogEntity(
                    eventType = "STARTED",
                    torrentName = "Global Engine",
                    trackerUrl = "${profile.clientFamily} ${profile.clientVersion} • ${ClientEmulationSpec.resolveOsToken(profile)}",
                    protocol = "SYSTEM",
                    details = "Bắt đầu phiên giả lập băng thông với cấu hình ${profile.name}"
                )
            )
        }

        engineTickerJob = viewModelScope.launch {
            while (isActive) {
                delay(1000L)
                tickSimulationSecond()
            }
        }
    }

    fun stopEngine() {
        engineTickerJob?.cancel()
        engineTickerJob = null
        viewModelScope.launch {
            repository.resetAllSpeeds()
            val profile = repository.getSelectedProfileOnce()
            repository.logEvent(
                EventLogEntity(
                    eventType = "STOPPED",
                    torrentName = "Global Engine",
                    trackerUrl = profile.name,
                    protocol = "SYSTEM",
                    details = "Đã tạm dừng vòng lặp phân bổ băng thông và gửi trạng thái STOPPED."
                )
            )
        }
        _dashboardState.value = _dashboardState.value.copy(
            isEngineRunning = false,
            totalUploadSpeedBps = 0L,
            statusBannerMessage = "Đã tạm dừng Engine giả lập"
        )
    }

    /**
     * Vòng lặp mỗi giây (1s Ticker) chuẩn thuật toán rursache/Seedr:
     * - Phân bổ băng thông có trọng số (Weighted Bandwidth Distribution) theo số lượng Leecher/Seeder
     * - Áp dụng nhiễu Jitter ngẫu nhiên để tốc độ biến thiên tự nhiên
     * - Kiểm tra mục tiêu Ratio để tự động hoàn tất torrent đạt ngưỡng
     * - Tự động gửi bản tin Announce định kỳ khi đồng hồ đếm ngược về 0
     */
    private suspend fun tickSimulationSecond() {
        val nowSec = System.currentTimeMillis() / 1000L
        val settings = globalSettings.value
        val profile = repository.getSelectedProfileOnce()
        val allTorrents = repository.getAllTorrentsOnce()

        val activeCandidates = allTorrents
            .filter { it.isActive }
            .filter { settings.keepZeroLeechesSeeding || it.leechers > 0 }
            .take(settings.simultaneousSeedLimit.coerceAtLeast(1))

        if (activeCandidates.isEmpty()) {
            val zeroHist = (_dashboardState.value.speedHistoryKbps.drop(1) + 0f)
            _dashboardState.value = _dashboardState.value.copy(
                totalUploadSpeedBps = 0L,
                speedHistoryKbps = zeroHist,
                nowEpochSec = nowSec
            )
            return
        }

        // Tính tốc độ cơ sở trung bình và áp dụng Jitter ±jitterPercent%
        val minBps = settings.minUploadRateKbps * 1024L
        val maxBps = max(minBps + 10240L, settings.maxUploadRateKbps * 1024L)
        val baseMidBps = Random.nextLong(minBps, maxBps + 1)
        val jitterFraction = (settings.jitterPercent.coerceIn(1, 80) / 100.0)
        val jitterMultiplier = 1.0 + Random.nextDouble(-jitterFraction, jitterFraction)
        val globalTargetBps = (baseMidBps * jitterMultiplier).toLong().coerceAtLeast(1024L)

        // Trọng số từng torrent dựa trên số leechers * 2.5 + seeders * 0.4
        val weights = activeCandidates.associate { t ->
            val w = (t.leechers.coerceAtLeast(1) * 2.5) + (t.seeders.coerceAtLeast(1) * 0.4)
            t.id to w
        }
        val totalWeight = weights.values.sum().coerceAtLeast(1.0)

        var tickTotalBps = 0L
        for (t in allTorrents) {
            if (activeCandidates.none { it.id == t.id }) {
                if (t.currentSpeedBps != 0L) {
                    repository.updateTorrent(t.copy(currentSpeedBps = 0L))
                }
                continue
            }

            val share = (weights[t.id] ?: 1.0) / totalWeight
            val microJitter = 1.0 + Random.nextDouble(-0.08, 0.08)
            val torrentBps = (globalTargetBps * share * microJitter).toLong().coerceAtLeast(512L)
            val newUploaded = t.uploadedBytes + torrentBps
            val newRatio = if (t.totalSize > 0) newUploaded.toDouble() / t.totalSize.toDouble() else 0.0

            // Kiểm tra đã đạt mục tiêu Ratio chưa
            if (t.targetRatio > 0.0 && newRatio >= t.targetRatio) {
                val stoppedTorrent = t.copy(
                    uploadedBytes = newUploaded,
                    currentSpeedBps = 0L,
                    isActive = false,
                    lastAnnounceStatus = "Đạt mục tiêu Ratio ${FormatUtils.formatRatio(t.targetRatio)}"
                )
                repository.updateTorrent(stoppedTorrent)
                repository.logEvent(
                    EventLogEntity(
                        eventType = "RATIO_REACHED",
                        torrentName = t.name,
                        trackerUrl = t.currentTrackerUrl(),
                        uploadedDeltaBytes = newUploaded,
                        seeders = t.seeders,
                        leechers = t.leechers,
                        protocol = "SYSTEM",
                        details = "Đã đạt Ratio mục tiêu (${FormatUtils.formatRatio(newRatio)} >= ${FormatUtils.formatRatio(t.targetRatio)}). Tự động dừng & gửi STOPPED."
                    )
                )
                continue
            }

            val shouldAnnounce = t.nextAnnounceEpochSec in 1..nowSec
            if (shouldAnnounce) {
                val updatedBeforeAnnounce = t.copy(
                    uploadedBytes = newUploaded,
                    currentSpeedBps = torrentBps,
                    nextAnnounceEpochSec = nowSec + t.announceIntervalSec.coerceAtLeast(300)
                )
                repository.updateTorrent(updatedBeforeAnnounce)
                triggerTrackerAnnounce(updatedBeforeAnnounce, event = null)
            } else {
                val nextEpoch = if (t.nextAnnounceEpochSec <= 0L) {
                    nowSec + t.announceIntervalSec.coerceAtLeast(300)
                } else {
                    t.nextAnnounceEpochSec
                }
                repository.updateTorrent(
                    t.copy(
                        uploadedBytes = newUploaded,
                        currentSpeedBps = torrentBps,
                        nextAnnounceEpochSec = nextEpoch
                    )
                )
            }
            tickTotalBps += torrentBps
        }

        val currentKbps = (tickTotalBps / 1024f)
        val updatedHistory = (_dashboardState.value.speedHistoryKbps.drop(1) + currentKbps)
        _dashboardState.value = _dashboardState.value.copy(
            totalUploadSpeedBps = tickTotalBps,
            sessionUploadedBytes = _dashboardState.value.sessionUploadedBytes + tickTotalBps,
            speedHistoryKbps = updatedHistory,
            nowEpochSec = nowSec
        )
    }

    fun forceAnnounceTorrent(torrent: TorrentEntity, eventType: String? = null) {
        viewModelScope.launch {
            triggerTrackerAnnounce(torrent, event = eventType)
        }
    }

    fun forceAnnounceAllActive() {
        viewModelScope.launch {
            val activeList = repository.getAllTorrentsOnce().filter { it.isActive }
            if (activeList.isEmpty()) {
                _dashboardState.value = _dashboardState.value.copy(
                    statusBannerMessage = "Không có Torrent nào đang kích hoạt để gửi Announce"
                )
                return@launch
            }
            for (t in activeList) {
                triggerTrackerAnnounce(t, event = null)
            }
            _dashboardState.value = _dashboardState.value.copy(
                statusBannerMessage = "Đã gửi bản tin Announce đồng loạt cho ${activeList.size} Torrent"
            )
        }
    }

    private suspend fun triggerTrackerAnnounce(torrent: TorrentEntity, event: String?) {
        val profile = repository.getSelectedProfileOnce()
        val settings = globalSettings.value
        val peerId = torrent.sessionPeerId.takeIf { it.length == 20 }
            ?: ClientEmulationSpec.generatePeerId(profile)
        val sessionKey = torrent.sessionKey.takeIf { it.isNotBlank() }
            ?: ClientEmulationSpec.generateSessionKey(profile)

        val readyTorrent = torrent.copy(sessionPeerId = peerId, sessionKey = sessionKey)
        val effectiveEvent = event ?: if (!readyTorrent.hasSentStarted) "started" else null

        val result = trackerAnnouncer.announceWithFailover(
            torrent = readyTorrent,
            profile = profile,
            event = effectiveEvent,
            overridePort = settings.emulatedListenPort,
            allowFailover = settings.autoFailoverTrackers
        )

        val nowSec = System.currentTimeMillis() / 1000L
        val updated = readyTorrent.copy(
            activeTrackerIndex = result.trackerIndex,
            seeders = result.seeders,
            leechers = result.leechers,
            announceIntervalSec = result.intervalSec,
            lastAnnounceEpochSec = nowSec,
            nextAnnounceEpochSec = nowSec + result.intervalSec,
            lastAnnounceStatus = result.statusSummary,
            hasSentStarted = true
        )
        repository.updateTorrent(updated)

        if (result.failedOver) {
            repository.logEvent(
                EventLogEntity(
                    eventType = "FAILOVER",
                    torrentName = torrent.name,
                    trackerUrl = result.trackerUrl,
                    uploadedDeltaBytes = torrent.uploadedBytes,
                    seeders = result.seeders,
                    leechers = result.leechers,
                    protocol = result.protocol,
                    details = "Tự động chuyển đổi dự phòng sang Tracker #${result.trackerIndex + 1}: ${result.trackerUrl}"
                )
            )
        }

        repository.logEvent(
            EventLogEntity(
                eventType = if (effectiveEvent == "started") "STARTED" else if (effectiveEvent == "stopped") "STOPPED" else "ANNOUNCE",
                torrentName = torrent.name,
                trackerUrl = result.trackerUrl,
                uploadedDeltaBytes = torrent.uploadedBytes,
                seeders = result.seeders,
                leechers = result.leechers,
                protocol = result.protocol,
                details = result.rawDetails
            )
        )
    }

    fun toggleTorrentActive(torrent: TorrentEntity) {
        viewModelScope.launch {
            val nextActive = !torrent.isActive
            val nowSec = System.currentTimeMillis() / 1000L
            val updated = torrent.copy(
                isActive = nextActive,
                currentSpeedBps = if (nextActive) torrent.currentSpeedBps else 0L,
                nextAnnounceEpochSec = if (nextActive) nowSec + torrent.announceIntervalSec else 0L,
                lastAnnounceStatus = if (nextActive) "Đang chạy phiên Seeding" else "Tạm dừng bởi người dùng"
            )
            repository.updateTorrent(updated)
            triggerTrackerAnnounce(updated, event = if (nextActive) "started" else "stopped")
        }
    }

    fun switchActiveTracker(torrent: TorrentEntity, newTrackerIndex: Int) {
        viewModelScope.launch {
            val trackers = torrent.trackerList()
            if (newTrackerIndex in trackers.indices) {
                val updated = torrent.copy(
                    activeTrackerIndex = newTrackerIndex,
                    lastAnnounceStatus = "Đã chuyển sang Tracker #${newTrackerIndex + 1}"
                )
                repository.updateTorrent(updated)
                triggerTrackerAnnounce(updated, event = "started")
            }
        }
    }

    fun updateTorrentTargetRatio(torrent: TorrentEntity, newTargetRatio: Double) {
        viewModelScope.launch {
            repository.updateTorrent(torrent.copy(targetRatio = newTargetRatio.coerceIn(0.1, 100.0)))
        }
    }

    fun deleteTorrent(torrent: TorrentEntity) {
        viewModelScope.launch {
            repository.deleteTorrent(torrent)
            repository.logEvent(
                EventLogEntity(
                    eventType = "STOPPED",
                    torrentName = torrent.name,
                    trackerUrl = torrent.currentTrackerUrl(),
                    uploadedDeltaBytes = torrent.uploadedBytes,
                    protocol = "SYSTEM",
                    details = "Đã xóa Torrent khỏi danh sách Seeding (Tổng đã báo cáo: ${FormatUtils.formatBytes(torrent.uploadedBytes)})."
                )
            )
        }
    }

    /**
     * Đọc tệp .torrent thực tế từ bộ nhớ thiết bị qua ContentResolver và giải mã Bencode.
     */
    fun parseTorrentFromUri(uri: Uri) {
        viewModelScope.launch {
            try {
                val context = getApplication<Application>()
                val rawBytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: throw IllegalArgumentException("Không thể đọc nội dung tệp đã chọn")
                val fallbackName = uri.lastPathSegment?.substringAfterLast("/") ?: "Imported.torrent"
                val parsed = BencodeParser.parseTorrentFile(rawBytes, fallbackName)
                _dashboardState.value = _dashboardState.value.copy(
                    pendingParsedTorrent = parsed,
                    statusBannerMessage = "Đã giải mã Bencode thành công: ${parsed.name}"
                )
            } catch (e: Exception) {
                _dashboardState.value = _dashboardState.value.copy(
                    statusBannerMessage = "Lỗi đọc tệp .torrent: ${e.message}"
                )
            }
        }
    }

    /**
     * Tạo tệp .torrent chuẩn Bencode ngay trong ứng dụng (từ tên, kích thước và danh sách Tracker)
     * rồi giải mã qua chính BencodeParser để tính SHA-1 info_hash thực tế.
     */
    fun createAndPreviewSyntheticTorrent(
        name: String,
        sizeGb: Double,
        trackersInput: String
    ) {
        viewModelScope.launch {
            val trackers = trackersInput.split("\n")
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .ifEmpty {
                    listOf(
                        "udp://tracker.opentrackr.org:1337/announce",
                        "http://tracker.opentrackr.org:1337/announce",
                        "udp://open.stealth.si:80/announce"
                    )
                }
            val sizeBytes = (sizeGb.coerceAtLeast(0.05) * 1024.0 * 1024.0 * 1024.0).toLong()
            val bytes = BencodeParser.buildSyntheticTorrentBytes(
                name = name.ifBlank { "ArchLinux-2026.11.01-x86_64.iso" },
                sizeBytes = sizeBytes,
                trackers = trackers
            )
            val parsed = BencodeParser.parseTorrentFile(bytes)
            _dashboardState.value = _dashboardState.value.copy(
                pendingParsedTorrent = parsed
            )
        }
    }

    fun dismissPendingTorrent() {
        _dashboardState.value = _dashboardState.value.copy(pendingParsedTorrent = null)
    }

    fun confirmAddParsedTorrent(meta: ParsedTorrentMeta, targetRatio: Double) {
        viewModelScope.launch {
            val profile = repository.getSelectedProfileOnce()
            val nowSec = System.currentTimeMillis() / 1000L
            val peerId = ClientEmulationSpec.generatePeerId(profile)
            val key = ClientEmulationSpec.generateSessionKey(profile)
            val entity = TorrentEntity(
                name = meta.name,
                infoHashHex = meta.infoHashHex,
                totalSize = meta.totalSize,
                trackersCsv = meta.trackers.joinToString("\n"),
                activeTrackerIndex = 0,
                uploadedBytes = 0L,
                downloadedBytes = 0L,
                leftBytes = 0L,
                currentSpeedBps = 0L,
                seeders = Random.nextInt(25, 160),
                leechers = Random.nextInt(8, 45),
                announceIntervalSec = 1800,
                nextAnnounceEpochSec = nowSec + 1800L,
                lastAnnounceEpochSec = nowSec,
                lastAnnounceStatus = "Đang gửi STARTED...",
                isActive = true,
                targetRatio = targetRatio.coerceIn(0.1, 100.0),
                hasSentStarted = false,
                sessionPeerId = peerId,
                sessionKey = key
            )
            val newId = repository.insertTorrent(entity)
            _dashboardState.value = _dashboardState.value.copy(
                pendingParsedTorrent = null,
                statusBannerMessage = "Đã thêm ${meta.name} (SHA-1: ${meta.infoHashHex.take(12)}...)"
            )
            val inserted = repository.getTorrentById(newId)
            if (inserted != null) {
                triggerTrackerAnnounce(inserted, event = "started")
            }
        }
    }

    // --- Quản lý Client & Operating System Profile ---
    fun selectClientProfile(profile: ClientProfileEntity) {
        viewModelScope.launch {
            repository.selectProfile(profile.id)
            // Cập nhật lại peer_id và key phiên mới cho các torrent đang chạy theo hồ sơ mới
            val torrentsList = repository.getAllTorrentsOnce()
            for (t in torrentsList) {
                repository.updateTorrent(
                    t.copy(
                        sessionPeerId = ClientEmulationSpec.generatePeerId(profile),
                        sessionKey = ClientEmulationSpec.generateSessionKey(profile)
                    )
                )
            }
            repository.logEvent(
                EventLogEntity(
                    eventType = "PROFILE",
                    torrentName = "Client & OS Studio",
                    trackerUrl = ClientEmulationSpec.buildUserAgent(profile),
                    protocol = "SYSTEM",
                    details = "Đã áp dụng hồ sơ '${profile.name}' | OS: ${ClientEmulationSpec.resolveOsToken(profile)} | Tiền tố peer_id: ${profile.peerIdPrefix}"
                )
            )
            _dashboardState.value = _dashboardState.value.copy(
                statusBannerMessage = "Đang giả lập: ${profile.name}"
            )
        }
    }

    fun saveClientProfile(profile: ClientProfileEntity, selectImmediately: Boolean = true) {
        viewModelScope.launch {
            val savedId = repository.saveProfile(profile)
            val actualId = if (profile.id != 0L) profile.id else savedId
            if (selectImmediately) {
                repository.selectProfile(actualId)
            }
            repository.logEvent(
                EventLogEntity(
                    eventType = "PROFILE",
                    torrentName = "Client & OS Studio",
                    trackerUrl = ClientEmulationSpec.buildUserAgent(profile),
                    protocol = "SYSTEM",
                    details = "Đã lưu cấu hình tùy chỉnh '${profile.name}' (Hệ điều hành: ${ClientEmulationSpec.resolveOsToken(profile)})"
                )
            )
            _dashboardState.value = _dashboardState.value.copy(
                statusBannerMessage = "Đã lưu & kích hoạt cấu hình: ${profile.name}"
            )
        }
    }

    fun deleteCustomProfile(profile: ClientProfileEntity) {
        if (profile.isBuiltIn) return
        viewModelScope.launch {
            repository.deleteCustomProfile(profile.id)
            val remaining = profiles.value.firstOrNull { it.id != profile.id }
            if (remaining != null && profile.isSelected) {
                repository.selectProfile(remaining.id)
            }
        }
    }

    // --- Công cụ Mạng & Cài đặt Toàn cục ---
    fun updateGlobalSettings(newSettings: GlobalEngineSettings) {
        viewModelScope.launch {
            repository.updateGlobalSettings(newSettings)
            _dashboardState.value = _dashboardState.value.copy(
                statusBannerMessage = "Đã cập nhật băng thông: ${newSettings.minUploadRateKbps} - ${newSettings.maxUploadRateKbps} KB/s (Jitter ±${newSettings.jitterPercent}%)"
            )
        }
    }

    fun runPortCheck(host: String, port: Int) {
        if (_dashboardState.value.isCheckingPort) return
        _dashboardState.value = _dashboardState.value.copy(isCheckingPort = true)
        viewModelScope.launch {
            val report = portChecker.checkPortViaCheckHost(host, port)
            _dashboardState.value = _dashboardState.value.copy(
                isCheckingPort = false,
                lastPortReport = report
            )
            repository.logEvent(
                EventLogEntity(
                    eventType = "PORT_CHECK",
                    torrentName = "Network Diagnostics",
                    trackerUrl = "${report.targetHost}:${report.targetPort}",
                    protocol = "SYSTEM",
                    details = report.summary
                )
            )
        }
    }

    fun clearEventLogs() {
        viewModelScope.launch {
            repository.clearLogs()
            _dashboardState.value = _dashboardState.value.copy(
                statusBannerMessage = "Đã xóa toàn bộ nhật ký sự kiện Announce"
            )
        }
    }

    fun clearStatusBanner() {
        _dashboardState.value = _dashboardState.value.copy(statusBannerMessage = null)
    }
}
