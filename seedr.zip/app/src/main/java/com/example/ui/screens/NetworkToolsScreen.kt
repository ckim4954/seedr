package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.GlobalEngineSettings
import com.example.engine.PortCheckReport
import com.example.ui.FormatUtils
import com.example.ui.theme.AlertCoral
import com.example.ui.theme.FailoverAmber
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.ProtocolCyan
import com.example.ui.theme.SignalEmerald
import com.example.ui.theme.SlateCardBorder
import com.example.ui.theme.SlateSurface
import com.example.ui.theme.SlateSurfaceElevated
import com.example.ui.theme.TextSecondary

/**
 * Màn hình Công cụ Mạng (Port Reachability Checker qua check-host.net)
 * & Cấu hình Thuật toán Băng thông + Jitter toàn cục của Seedr Engine.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun NetworkToolsScreen(
    globalSettings: GlobalEngineSettings,
    isCheckingPort: Boolean,
    lastPortReport: PortCheckReport?,
    onRunPortCheck: (String, Int) -> Unit,
    onSaveGlobalSettings: (GlobalEngineSettings) -> Unit,
    modifier: Modifier = Modifier
) {
    var hostInput by rememberSaveable { mutableStateOf("tracker.opentrackr.org") }
    var portInput by rememberSaveable { mutableStateOf("1337") }

    var minSpeedKbps by rememberSaveable { mutableIntStateOf(globalSettings.minUploadRateKbps) }
    var maxSpeedKbps by rememberSaveable { mutableIntStateOf(globalSettings.maxUploadRateKbps) }
    var jitterPercent by rememberSaveable { mutableIntStateOf(globalSettings.jitterPercent) }
    var defaultRatio by rememberSaveable { mutableDoubleStateOf(globalSettings.defaultTargetRatio) }
    var simultaneousLimit by rememberSaveable { mutableIntStateOf(globalSettings.simultaneousSeedLimit) }
    var listenPortText by rememberSaveable { mutableStateOf(globalSettings.emulatedListenPort.toString()) }
    var autoFailover by rememberSaveable { mutableStateOf(globalSettings.autoFailoverTrackers) }
    var keepZeroLeeches by rememberSaveable { mutableStateOf(globalSettings.keepZeroLeechesSeeding) }

    LaunchedEffect(globalSettings) {
        minSpeedKbps = globalSettings.minUploadRateKbps
        maxSpeedKbps = globalSettings.maxUploadRateKbps
        jitterPercent = globalSettings.jitterPercent
        defaultRatio = globalSettings.defaultTargetRatio
        simultaneousLimit = globalSettings.simultaneousSeedLimit
        listenPortText = globalSettings.emulatedListenPort.toString()
        autoFailover = globalSettings.autoFailoverTrackers
        keepZeroLeeches = globalSettings.keepZeroLeechesSeeding
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .testTag("network_tools_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. PORT REACHABILITY CHECKER (check-host.net)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ProtocolCyan.copy(alpha = 0.4f), RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SlateSurface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Public,
                            contentDescription = null,
                            tint = ProtocolCyan
                        )
                        Column {
                            Text(
                                text = "KIỂM TRA CỔNG QUỐC TẾ (CHECK-HOST.NET)",
                                style = MaterialTheme.typography.titleMedium,
                                color = ProtocolCyan,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Kiểm tra khả năng kết nối tới cổng Tracker hoặc cổng lắng nghe từ các nút mạng quốc tế",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }
                    }

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        AssistChip(
                            onClick = {
                                hostInput = "tracker.opentrackr.org"
                                portInput = "1337"
                            },
                            label = { Text("opentrackr:1337") }
                        )
                        AssistChip(
                            onClick = {
                                hostInput = "bttracker.debian.org"
                                portInput = "6969"
                            },
                            label = { Text("debian:6969") }
                        )
                        AssistChip(
                            onClick = {
                                hostInput = "torrent.ubuntu.com"
                                portInput = "443"
                            },
                            label = { Text("ubuntu:443") }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = hostInput,
                            onValueChange = { hostInput = it },
                            label = { Text("Địa chỉ Host / IP") },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1.8f)
                                .testTag("port_check_host_input")
                        )
                        OutlinedTextField(
                            value = portInput,
                            onValueChange = { portInput = it },
                            label = { Text("Cổng (Port)") },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("port_check_port_input")
                        )
                    }

                    Button(
                        onClick = {
                            val p = portInput.toIntOrNull()?.coerceIn(1, 65535) ?: 1337
                            onRunPortCheck(hostInput, p)
                        },
                        enabled = !isCheckingPort,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("run_port_check_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ProtocolCyan,
                            contentColor = Color(0xFF082F49)
                        )
                    ) {
                        if (isCheckingPort) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = Color(0xFF082F49)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Đang kiểm tra các nút mạng...", fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Default.NetworkCheck, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Kiểm tra Cổng (check-host.net)", fontWeight = FontWeight.Bold)
                        }
                    }

                    if (lastPortReport != null) {
                        Surface(
                            color = ObsidianBackground,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = lastPortReport.summary,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = SignalEmerald
                                )
                                HorizontalDivider(color = SlateCardBorder)
                                lastPortReport.nodes.forEach { node ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(
                                                imageVector = if (node.reachable) Icons.Default.CheckCircle else Icons.Default.ErrorOutline,
                                                contentDescription = null,
                                                tint = if (node.reachable) SignalEmerald else FailoverAmber,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Text(
                                                text = node.locationLabel,
                                                style = MaterialTheme.typography.bodyMedium
                                            )
                                        }
                                        Text(
                                            text = node.message,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = if (node.reachable) SignalEmerald else AlertCoral
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 2. CẤU HÌNH THUẬT TOÁN BĂNG THÔNG & JITTER TOÀN CỤC
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SlateCardBorder, RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SlateSurface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Speed,
                            contentDescription = null,
                            tint = SignalEmerald
                        )
                        Column {
                            Text(
                                text = "THUẬT TOÁN BĂNG THÔNG & JITTER",
                                style = MaterialTheme.typography.titleMedium,
                                color = SignalEmerald,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Điều chỉnh tốc độ Upload tối thiểu/tối đa, biên độ dao động Jitter và giới hạn phiên đồng thời",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }
                    }

                    // Min Speed
                    Text(
                        text = "Tốc độ Upload tối thiểu: $minSpeedKbps KB/s",
                        style = MaterialTheme.typography.labelLarge
                    )
                    Slider(
                        value = minSpeedKbps.toFloat(),
                        onValueChange = {
                            minSpeedKbps = it.toInt()
                            if (maxSpeedKbps < minSpeedKbps + 50) {
                                maxSpeedKbps = minSpeedKbps + 50
                            }
                        },
                        valueRange = 50f..10000f
                    )

                    // Max Speed
                    Text(
                        text = "Tốc độ Upload tối đa: $maxSpeedKbps KB/s (${FormatUtils.formatSpeed(maxSpeedKbps * 1024L)})",
                        style = MaterialTheme.typography.labelLarge
                    )
                    Slider(
                        value = maxSpeedKbps.toFloat(),
                        onValueChange = {
                            maxSpeedKbps = it.toInt().coerceAtLeast(minSpeedKbps + 50)
                        },
                        valueRange = 100f..25000f
                    )

                    // Jitter Percent
                    Text(
                        text = "Biên độ dao động ngẫu nhiên (Traffic Jitter): ±$jitterPercent%",
                        style = MaterialTheme.typography.labelLarge,
                        color = ProtocolCyan
                    )
                    Slider(
                        value = jitterPercent.toFloat(),
                        onValueChange = { jitterPercent = it.toInt() },
                        valueRange = 2f..60f
                    )

                    // Default Target Ratio & Simultaneous Limit
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Ratio mục tiêu: ${FormatUtils.formatRatio(defaultRatio)}",
                                style = MaterialTheme.typography.labelLarge
                            )
                            Slider(
                                value = defaultRatio.toFloat(),
                                onValueChange = { defaultRatio = it.toDouble() },
                                valueRange = 0.5f..15f
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Số Torrent chạy cùng lúc: $simultaneousLimit",
                                style = MaterialTheme.typography.labelLarge
                            )
                            Slider(
                                value = simultaneousLimit.toFloat(),
                                onValueChange = { simultaneousLimit = it.toInt() },
                                valueRange = 1f..15f
                            )
                        }
                    }

                    OutlinedTextField(
                        value = listenPortText,
                        onValueChange = { listenPortText = it },
                        label = { Text("Cổng lắng nghe báo cáo lên Tracker (Emulated Port)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Surface(
                        color = SlateSurfaceElevated,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Tự động chuyển đổi dự phòng (Tracker Failover)",
                                    style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.weight(1f)
                                )
                                Switch(
                                    checked = autoFailover,
                                    onCheckedChange = { autoFailover = it }
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Giữ Seeding ngay cả khi số Leecher = 0",
                                    style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.weight(1f)
                                )
                                Switch(
                                    checked = keepZeroLeeches,
                                    onCheckedChange = { keepZeroLeeches = it }
                                )
                            }
                        }
                    }

                    Button(
                        onClick = {
                            onSaveGlobalSettings(
                                GlobalEngineSettings(
                                    minUploadRateKbps = minSpeedKbps,
                                    maxUploadRateKbps = maxSpeedKbps,
                                    jitterPercent = jitterPercent,
                                    defaultTargetRatio = defaultRatio,
                                    simultaneousSeedLimit = simultaneousLimit,
                                    emulatedListenPort = listenPortText.toIntOrNull()?.coerceIn(1024, 65535) ?: 51413,
                                    autoFailoverTrackers = autoFailover,
                                    keepZeroLeechesSeeding = keepZeroLeeches
                                )
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("save_global_settings_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SignalEmerald,
                            contentColor = Color(0xFF042F2E)
                        )
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Lưu Cấu Hình Băng Thông & Jitter", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
