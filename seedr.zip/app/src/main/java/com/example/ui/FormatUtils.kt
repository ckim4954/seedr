package com.example.ui

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object FormatUtils {

    fun formatBytes(bytes: Long): String {
        if (bytes <= 0L) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        var value = bytes.toDouble()
        var unitIndex = 0
        while (value >= 1024.0 && unitIndex < units.lastIndex) {
            value /= 1024.0
            unitIndex++
        }
        return if (unitIndex <= 1) {
            String.format(Locale.US, "%.0f %s", value, units[unitIndex])
        } else {
            String.format(Locale.US, "%.2f %s", value, units[unitIndex])
        }
    }

    fun formatSpeed(bytesPerSec: Long): String {
        if (bytesPerSec <= 0L) return "0.0 KB/s"
        val kbps = bytesPerSec / 1024.0
        return if (kbps >= 1024.0) {
            String.format(Locale.US, "%.2f MB/s", kbps / 1024.0)
        } else {
            String.format(Locale.US, "%.1f KB/s", kbps)
        }
    }

    fun formatRatio(ratio: Double): String = String.format(Locale.US, "%.2f", ratio)

    fun formatCountdown(nextAnnounceEpochSec: Long, nowEpochSec: Long): String {
        if (nextAnnounceEpochSec <= 0L) return "--:--"
        val diff = (nextAnnounceEpochSec - nowEpochSec).coerceAtLeast(0L)
        val mins = diff / 60L
        val secs = diff % 60L
        return String.format(Locale.US, "%02d:%02d", mins, secs)
    }

    fun formatTime(timestampMillis: Long): String {
        val sdf = SimpleDateFormat("HH:mm:ss • dd/MM", Locale.getDefault())
        return sdf.format(Date(timestampMillis))
    }
}
