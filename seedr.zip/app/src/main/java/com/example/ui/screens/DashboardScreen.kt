package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.ClientProfileEntity
import com.example.data.GlobalEngineSettings
import com.example.data.TorrentEntity
import com.example.engine.ClientEmulationSpec
import com.example.engine.ParsedTorrentMeta
import com.example.ui.FormatUtils
import com.example.ui.SeedrDashboardState
import com.example.ui.theme.AlertCoral
import com.example.ui.theme.FailoverAmber
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.ProtocolCyan
import com.example.ui.theme.SignalEmerald
import com.example.ui.theme.SlateCardBorder
import com.example.ui.theme.SlateSurface
import com.example.ui.theme.SlateSurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DashboardScreen(
    dashboardState: SeedrDashboardState,
    torrents: List<TorrentEntity>,
    selectedProfile: ClientProfileEntity?,
    globalSettings: GlobalEngineSettings,
    onToggleEngine: () -> Unit,
    onForceAnnounceAll: () -> Unit,
    onPickTorrentUri: (android.net.Uri) -> Unit,
    onCreateSyntheticTorrent: (String, Double, String) -> Unit,
    onConfirmParsedTorrent: (ParsedTorrentMeta, Double) -> Unit,
    onDismissParsedTorrent: () -> Unit,
    onToggleTorrent: (TorrentEntity) -> Unit,
    onForceAnnounceTorrent: (TorrentEntity, String?) -> Unit,
    onSwitchTracker: (TorrentEntity, Int) -> Unit,
    onUpdateTargetRatio: (TorrentEntity, Double) -> Unit,
    onDeleteTorrent: (TorrentEntity) -> Unit,
    onOpenProfileStudio: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showSyntheticBuilderDialog by rememberSaveable { mutableStateOf(false) }

    val torrentFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            onPickTorrentUri(uri)
        }
    }

    val totalUploadedAllTime = remember(torrents) {
        torrents.sumOf { it.uploadedBytes }
    }
    val activeCount = remember(torrents) {
        torrents.count { it.isActive }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .testTag("dashboard_list"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Telemetry Hero Card & Live Bandwidth Waveform
        item {
            TelemetryHeroCard(
                dashboardState = dashboardState,
                totalUploadedAllTime = totalUploadedAllTime,
                activeCount = activeCount,
                totalTorrentCount = torrents.size,
                selectedProfile = selectedProfile,
                globalSettings = globalSettings,
                onToggleEngine = onToggleEngine,
                onForceAnnounceAll = onForceAnnounceAll,
                onOpenProfileStudio = onOpenProfileStudio
            )
        }

        // 2. Action Bar: Chọn tệp .torrent hoặc Tạo .torrent Bencode mới
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { torrentFileLauncher.launch("*/*") },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("pick_torrent_file_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SignalEmerald,
                        contentColor = Color(0xFF032219)
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.FileOpen,
                        contentDescription = "Chọn tệp .torrent",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Mở tệp .torrent",
                        fontWeight = FontWeight.Bold
                    )
                }

                FilledTonalButton(
                    onClick = { showSyntheticBuilderDialog = true },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("open_torrent_builder_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Tạo Torrent Bencode",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Tạo .torrent mẫu",
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // 3. Section Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "DANH SÁCH PHIÊN SEEDING (${torrents.size})",
                    style = MaterialTheme.typography.labelLarge,
                    color = TextSecondary
                )
                Text(
                    text = "Jitter ±${globalSettings.jitterPercent}% • Max ${globalSettings.simultaneousSeedLimit} phiên",
                    style = MaterialTheme.typography.labelSmall,
                    color = ProtocolCyan
                )
            }
        }

        // 4. Empty State or Torrent Cards
        if (torrents.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, SlateCardBorder, RoundedCornerShape(16.dp)),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SlateSurface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Router,
                            contentDescription = null,
                            tint = ProtocolCyan,
                            modifier = Modifier.size(44.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Chưa có tệp .torrent nào trong hàng đợi",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Nhấn 'Mở tệp .torrent' để đọc tệp từ bộ nhớ máy hoặc 'Tạo .torrent mẫu' để kiểm thử bộ giải mã Bencode & giao thức UDP BEP-15.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                }
            }
        } else {
            items(torrents, key = { it.id }) { torrent ->
                TorrentSessionCard(
                    torrent = torrent,
                    nowEpochSec = dashboardState.nowEpochSec,
                    isEngineRunning = dashboardState.isEngineRunning,
                    onToggleActive = { onToggleTorrent(torrent) },
                    onForceAnnounce = { ev -> onForceAnnounceTorrent(torrent, ev) },
                    onSwitchTracker = { idx -> onSwitchTracker(torrent, idx) },
                    onUpdateTargetRatio = { ratio -> onUpdateTargetRatio(torrent, ratio) },
                    onDelete = { onDeleteTorrent(torrent) }
                )
            }
        }
    }

    // Hộp thoại xác nhận thông tin Bencode .torrent vừa giải mã
    val pendingMeta = dashboardState.pendingParsedTorrent
    if (pendingMeta != null) {
        ParsedTorrentPreviewDialog(
            meta = pendingMeta,
            defaultTargetRatio = globalSettings.defaultTargetRatio,
            onConfirm = { ratio -> onConfirmParsedTorrent(pendingMeta, ratio) },
            onDismiss = onDismissParsedTorrent
        )
    }

    // Hộp thoại tạo tệp .torrent chuẩn Bencode ngay trên máy
    if (showSyntheticBuilderDialog) {
        SyntheticTorrentBuilderDialog(
            onDismiss = { showSyntheticBuilderDialog = false },
            onCreate = { name, sizeGb, trackers ->
                showSyntheticBuilderDialog = false
                onCreateSyntheticTorrent(name, sizeGb, trackers)
            }
        )
    }
}

@Composable
private fun TelemetryHeroCard(
    dashboardState: SeedrDashboardState,
    totalUploadedAllTime: Long,
    activeCount: Int,
    totalTorrentCount: Int,
    selectedProfile: ClientProfileEntity?,
    globalSettings: GlobalEngineSettings,
    onToggleEngine: () -> Unit,
    onForceAnnounceAll: () -> Unit,
    onOpenProfileStudio: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = if (dashboardState.isEngineRunning) SignalEmerald.copy(alpha = 0.45f) else SlateCardBorder,
                shape = RoundedCornerShape(20.dp)
            ),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = SlateSurface)
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Image(
                painter = painterResource(id = R.drawable.img_seedr_banner_1794376284033),
                contentDescription = "Seedr Network Telemetry Banner",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .matchParentSize(),
                alpha = 0.22f
            )
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                ObsidianBackground.copy(alpha = 0.55f),
                                SlateSurface.copy(alpha = 0.94f),
                                SlateSurface
                            )
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Dòng trạng thái Engine & nút bật/tắt
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(if (dashboardState.isEngineRunning) SignalEmerald else FailoverAmber)
                        )
                        Text(
                            text = if (dashboardState.isEngineRunning) {
                                "SEEDR ENGINE • ACTIVE ($activeCount/$totalTorrentCount)"
                            } else {
                                "SEEDR ENGINE • PAUSED"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = if (dashboardState.isEngineRunning) SignalEmerald else FailoverAmber
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        IconButton(
                            onClick = onForceAnnounceAll,
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(SlateSurfaceElevated)
                                .testTag("force_announce_all_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = "Force Announce tất cả",
                                tint = ProtocolCyan
                            )
                        }

                        Button(
                            onClick = onToggleEngine,
                            modifier = Modifier
                                .height(38.dp)
                                .testTag("engine_toggle_button"),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (dashboardState.isEngineRunning) AlertCoral.copy(alpha = 0.2f) else SignalEmerald,
                                contentColor = if (dashboardState.isEngineRunning) AlertCoral else Color(0xFF042F2E)
                            )
                        ) {
                            Icon(
                                imageVector = if (dashboardState.isEngineRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (dashboardState.isEngineRunning) "Dừng" else "Chạy Engine",
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }

                // Tốc độ tải lên trực tiếp & Tổng dung lượng đã báo cáo
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column {
                        Text(
                            text = "TỐC ĐỘ UPLOAD GIẢ LẬP",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                        Text(
                            text = FormatUtils.formatSpeed(dashboardState.totalUploadSpeedBps),
                            fontFamily = JetBrainsMonoFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 28.sp,
                            color = SignalEmerald
                        )
                        Text(
                            text = "Khung mục tiêu: ${globalSettings.minUploadRateKbps}–${globalSettings.maxUploadRateKbps} KB/s",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "TỔNG ĐÃ BÁO CÁO",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                        Text(
                            text = FormatUtils.formatBytes(totalUploadedAllTime),
                            fontFamily = JetBrainsMonoFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = ProtocolCyan
                        )
                        Text(
                            text = "Phiên này: +${FormatUtils.formatBytes(dashboardState.sessionUploadedBytes)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                    }
                }

                // Biểu đồ xung nhịp tốc độ (Live Waveform Canvas)
                BandwidthWaveformChart(
                    historyKbps = dashboardState.speedHistoryKbps,
                    maxReferenceKbps = globalSettings.maxUploadRateKbps.toFloat().coerceAtLeast(500f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(68.dp)
                )

                // Thanh hiển thị Client Profile & Operating System đang áp dụng
                if (selectedProfile != null) {
                    val osToken = ClientEmulationSpec.resolveOsToken(selectedProfile)
                    val userAgent = ClientEmulationSpec.buildUserAgent(selectedProfile)
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable(onClick = onOpenProfileStudio)
                            .testTag("active_profile_banner"),
                        color = SlateSurfaceElevated,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Computer,
                                    contentDescription = null,
                                    tint = ProtocolCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                                Column {
                                    Text(
                                        text = "${selectedProfile.clientFamily} ${selectedProfile.clientVersion} • OS: ${selectedProfile.osFamily}",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "UA: $userAgent | Port: ${globalSettings.emulatedListenPort}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = "Chỉnh sửa Client & OS",
                                tint = SignalEmerald,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BandwidthWaveformChart(
    historyKbps: List<Float>,
    maxReferenceKbps: Float,
    modifier: Modifier = Modifier
) {
    Canvas(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(ObsidianBackground.copy(alpha = 0.65f))
            .padding(vertical = 6.dp, horizontal = 4.dp)
    ) {
        if (historyKbps.size < 2) return@Canvas
        val w = size.width
        val h = size.height
        val peak = (historyKbps.maxOrNull() ?: 100f).coerceAtLeast(maxReferenceKbps * 1.15f).coerceAtLeast(100f)
        val stepX = w / (historyKbps.size - 1).toFloat()

        // Lưới ngang mờ
        for (i in 1..2) {
            val y = h * (i / 3f)
            drawLine(
                color = SlateCardBorder.copy(alpha = 0.5f),
                start = Offset(0f, y),
                end = Offset(w, y),
                strokeWidth = 1f
            )
        }

        val linePath = Path()
        val fillPath = Path()
        historyKbps.forEachIndexed { index, kbps ->
            val x = index * stepX
            val normalized = (kbps / peak).coerceIn(0f, 1f)
            val y = h - (normalized * (h - 8f)) - 4f
            if (index == 0) {
                linePath.moveTo(x, y)
                fillPath.moveTo(x, h)
                fillPath.lineTo(x, y)
            } else {
                linePath.lineTo(x, y)
                fillPath.lineTo(x, y)
            }
        }
        fillPath.lineTo(w, h)
        fillPath.close()

        drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(
                colors = listOf(
                    SignalEmerald.copy(alpha = 0.35f),
                    ProtocolCyan.copy(alpha = 0.05f),
                    Color.Transparent
                )
            )
        )
        drawPath(
            path = linePath,
            color = SignalEmerald,
            style = Stroke(width = 3f, cap = StrokeCap.Round)
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TorrentSessionCard(
    torrent: TorrentEntity,
    nowEpochSec: Long,
    isEngineRunning: Boolean,
    onToggleActive: () -> Unit,
    onForceAnnounce: (String?) -> Unit,
    onSwitchTracker: (Int) -> Unit,
    onUpdateTargetRatio: (Double) -> Unit,
    onDelete: () -> Unit
) {
    var expanded by rememberSaveable(torrent.id) { mutableStateOf(false) }
    var editingRatio by rememberSaveable(torrent.id) { mutableStateOf(false) }
    var sliderRatio by remember(torrent.targetRatio) { mutableDoubleStateOf(torrent.targetRatio) }

    val trackers = torrent.trackerList()
    val currentTracker = torrent.currentTrackerUrl()
    val isUdp = currentTracker.startsWith("udp://", ignoreCase = true)
    val protocolBadge = if (isUdp) "UDP BEP-15" else if (currentTracker.startsWith("https://", true)) "HTTPS" else "HTTP"
    val ratio = torrent.currentRatio()
    val progress = if (torrent.targetRatio > 0) (ratio / torrent.targetRatio).toFloat().coerceIn(0f, 1f) else 0f

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = if (torrent.isActive && isEngineRunning) SignalEmerald.copy(alpha = 0.35f) else SlateCardBorder,
                shape = RoundedCornerShape(16.dp)
            )
            .testTag("torrent_card_${torrent.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SlateSurface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Hàng tiêu đề Torrent + Nút bật/tắt
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            color = if (isUdp) ProtocolCyan.copy(alpha = 0.16f) else SignalEmerald.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = protocolBadge,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isUdp) ProtocolCyan else SignalEmerald,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Text(
                            text = torrent.lastAnnounceStatus,
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = torrent.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Switch(
                    checked = torrent.isActive,
                    onCheckedChange = { onToggleActive() },
                    modifier = Modifier.testTag("torrent_switch_${torrent.id}")
                )
            }

            // Hàng chỉ số tốc độ, Uploaded, Ratio, Seeders/Leechers
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(SlateSurfaceElevated)
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                MetricColumn(
                    label = "TỐC ĐỘ",
                    value = FormatUtils.formatSpeed(torrent.currentSpeedBps),
                    valueColor = if (torrent.currentSpeedBps > 0) SignalEmerald else TextSecondary
                )
                MetricColumn(
                    label = "ĐÃ UPLOAD / GỐC",
                    value = "${FormatUtils.formatBytes(torrent.uploadedBytes)} / ${FormatUtils.formatBytes(torrent.totalSize)}",
                    valueColor = MaterialTheme.colorScheme.onSurface
                )
                MetricColumn(
                    label = "RATIO",
                    value = "${FormatUtils.formatRatio(ratio)} / ${FormatUtils.formatRatio(torrent.targetRatio)}",
                    valueColor = ProtocolCyan
                )
            }

            // Thanh tiến độ Ratio
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = SignalEmerald,
                    trackColor = SlateSurfaceElevated
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Swarm: ${torrent.seeders} Seeders • ${torrent.leechers} Leechers",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                    Text(
                        text = "Announce kế: ${FormatUtils.formatCountdown(torrent.nextAnnounceEpochSec, nowEpochSec)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = FailoverAmber
                    )
                }
            }

            // Các nút thao tác nhanh
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { onForceAnnounce(null) },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("force_announce_${torrent.id}"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Announce ngay", style = MaterialTheme.typography.labelSmall)
                    }

                    OutlinedButton(
                        onClick = { editingRatio = !editingRatio },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.height(34.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Speed,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Mục tiêu Ratio", style = MaterialTheme.typography.labelSmall)
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier
                            .size(34.dp)
                            .testTag("delete_torrent_${torrent.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Xóa Torrent",
                            tint = AlertCoral,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = { expanded = !expanded },
                        modifier = Modifier
                            .size(34.dp)
                            .testTag("expand_torrent_${torrent.id}")
                    ) {
                        Icon(
                            imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = "Chi tiết giao thức",
                            tint = TextSecondary
                        )
                    }
                }
            }

            // Thanh chỉnh nhanh mục tiêu Ratio
            AnimatedVisibility(visible = editingRatio) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(SlateSurfaceElevated)
                        .padding(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Tự động dừng khi đạt Ratio: ${FormatUtils.formatRatio(sliderRatio)}",
                            style = MaterialTheme.typography.labelLarge
                        )
                        TextButton(
                            onClick = {
                                onUpdateTargetRatio(sliderRatio)
                                editingRatio = false
                            }
                        ) {
                            Text("Lưu", color = SignalEmerald, fontWeight = FontWeight.Bold)
                        }
                    }
                    Slider(
                        value = sliderRatio.toFloat(),
                        onValueChange = { sliderRatio = it.toDouble() },
                        valueRange = 0.5f..20f
                    )
                }
            }

            // Khung chi tiết InfoHash, PeerID, Key & Danh sách Tracker dự phòng (Failover)
            AnimatedVisibility(visible = expanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(ObsidianBackground.copy(alpha = 0.8f))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "THÔNG SỐ BENCODE & PHIÊN ANNOUNCE",
                        style = MaterialTheme.typography.labelSmall,
                        color = ProtocolCyan
                    )
                    Text(
                        text = "SHA-1 info_hash: ${torrent.infoHashHex}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                    Text(
                        text = "Session peer_id: ${torrent.sessionPeerId.ifBlank { "Sẵn sàng sinh tự động" }} | Key: ${torrent.sessionKey.ifBlank { "AUTO" }}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                    HorizontalDivider(color = SlateCardBorder, modifier = Modifier.padding(vertical = 4.dp))
                    Text(
                        text = "DANH SÁCH TRACKER (${trackers.size} — chạm để chuyển đổi):",
                        style = MaterialTheme.typography.labelSmall,
                        color = SignalEmerald
                    )
                    trackers.forEachIndexed { idx, trUrl ->
                        val isCurrent = idx == torrent.activeTrackerIndex
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isCurrent) SignalEmerald.copy(alpha = 0.14f) else Color.Transparent)
                                .clickable { onSwitchTracker(idx) }
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = if (isCurrent) SignalEmerald else TextMuted,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = "#${idx + 1}: $trUrl",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isCurrent) SignalEmerald else TextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricColumn(
    label: String,
    value: String,
    valueColor: Color
) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = TextMuted,
            fontSize = 10.sp
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelSmall,
            color = valueColor,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp
        )
    }
}

@Composable
private fun ParsedTorrentPreviewDialog(
    meta: ParsedTorrentMeta,
    defaultTargetRatio: Double,
    onConfirm: (Double) -> Unit,
    onDismiss: () -> Unit
) {
    var targetRatio by remember { mutableDoubleStateOf(defaultTargetRatio) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SlateSurface,
        title = {
            Text(
                text = "Kết quả Giải mã Bencode .torrent",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = meta.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = SignalEmerald,
                    fontWeight = FontWeight.Bold
                )
                Surface(
                    color = ObsidianBackground,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "SHA-1 InfoHash (20-byte):",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                        Text(
                            text = meta.infoHashHex,
                            style = MaterialTheme.typography.labelSmall,
                            color = ProtocolCyan
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Dung lượng: ${FormatUtils.formatBytes(meta.totalSize)} • Piece: ${FormatUtils.formatBytes(meta.pieceLength)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                        Text(
                            text = "Số Tracker phát hiện: ${meta.trackers.size} (${meta.trackers.firstOrNull().orEmpty()})",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }
                }

                Text(
                    text = "Mục tiêu Ratio tự dừng: ${FormatUtils.formatRatio(targetRatio)}",
                    style = MaterialTheme.typography.bodyMedium
                )
                Slider(
                    value = targetRatio.toFloat(),
                    onValueChange = { targetRatio = it.toDouble() },
                    valueRange = 0.5f..15f
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(targetRatio) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = SignalEmerald,
                    contentColor = Color(0xFF042F2E)
                ),
                modifier = Modifier.testTag("confirm_add_torrent_button")
            ) {
                Text("Bắt đầu Seeding", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Hủy")
            }
        }
    )
}

@Composable
private fun SyntheticTorrentBuilderDialog(
    onDismiss: () -> Unit,
    onCreate: (String, Double, String) -> Unit
) {
    var name by rememberSaveable { mutableStateOf("Fedora-Workstation-Live-x86_64-41.iso") }
    var sizeGbText by rememberSaveable { mutableStateOf("2.35") }
    var trackersText by rememberSaveable {
        mutableStateOf(
            "udp://tracker.opentrackr.org:1337/announce\n" +
                "http://tracker.opentrackr.org:1337/announce\n" +
                "udp://open.stealth.si:80/announce"
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SlateSurface,
        title = {
            Text(
                text = "Tạo tệp .torrent chuẩn Bencode",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Tạo cấu trúc Bencode nhị phân thật trên máy để trích xuất SHA-1 info_hash và thử nghiệm luồng HTTP/UDP BEP-15.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Tên gói nội dung Torrent") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = sizeGbText,
                    onValueChange = { sizeGbText = it },
                    label = { Text("Dung lượng giả lập (GB)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = trackersText,
                    onValueChange = { trackersText = it },
                    label = { Text("Danh sách Tracker (HTTP / UDP BEP-15, mỗi dòng 1 URL)") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val gb = sizeGbText.toDoubleOrNull() ?: 2.0
                    onCreate(name, gb, trackersText)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = SignalEmerald,
                    contentColor = Color(0xFF042F2E)
                ),
                modifier = Modifier.testTag("generate_bencode_torrent_button")
            ) {
                Text("Tạo & Giải mã SHA-1", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Đóng")
            }
        }
    )
}
