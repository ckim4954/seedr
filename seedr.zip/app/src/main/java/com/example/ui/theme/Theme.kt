package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SeedrDarkColorScheme = darkColorScheme(
    primary = SignalEmerald,
    onPrimary = Color(0xFF042F2E),
    primaryContainer = SignalEmeraldDim,
    onPrimaryContainer = SignalEmeraldLight,
    secondary = ProtocolCyan,
    onSecondary = Color(0xFF082F49),
    secondaryContainer = ProtocolCyanDim,
    onSecondaryContainer = Color(0xFFBAE6FD),
    tertiary = FailoverAmber,
    onTertiary = Color(0xFF451A03),
    tertiaryContainer = FailoverAmberDim,
    onTertiaryContainer = Color(0xFFFDE68A),
    error = AlertCoral,
    onError = Color.White,
    errorContainer = AlertCoralDim,
    onErrorContainer = Color(0xFFFECACA),
    background = ObsidianBackground,
    onBackground = TextPrimary,
    surface = SlateSurface,
    onSurface = TextPrimary,
    surfaceVariant = SlateSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = SlateCardBorder
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SeedrDarkColorScheme,
        typography = Typography,
        content = content
    )
}
