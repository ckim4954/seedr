package com.example.engine

import java.io.ByteArrayOutputStream
import java.nio.charset.StandardCharsets
import java.security.MessageDigest

/**
 * Bộ giải mã & mã hóa Bencode chuẩn BitTorrent (tương thích 100% với rursache/Seedr).
 * Trích xuất chính xác byte slice của dictionary "info" trong tệp .torrent để băm SHA-1 20-byte info_hash.
 */
sealed class BValue {
    data class BInt(val value: Long) : BValue()
    data class BBytes(val bytes: ByteArray) : BValue() {
        fun asUtf8(): String = String(bytes, StandardCharsets.UTF_8)
    }
    data class BList(val items: List<BValue>) : BValue()
    data class BDict(
        val entries: Map<String, BValue>,
        val rawStartIndex: Int = 0,
        val rawEndIndex: Int = 0
    ) : BValue()
}

data class ParsedTorrentMeta(
    val name: String,
    val infoHashBytes: ByteArray,
    val infoHashHex: String,
    val totalSize: Long,
    val trackers: List<String>,
    val pieceLength: Long,
    val createdBy: String,
    val comment: String,
    val fileCount: Int
)

object BencodeParser {

    fun parseTorrentFile(rawBytes: ByteArray, fallbackName: String = "Unnamed.torrent"): ParsedTorrentMeta {
        val parser = Cursor(rawBytes)
        val root = parser.readValue() as? BValue.BDict
            ?: throw IllegalArgumentException("Tệp .torrent không hợp lệ: gốc không phải Bencode Dictionary")

        val infoDict = root.entries["info"] as? BValue.BDict
            ?: throw IllegalArgumentException("Tệp .torrent thiếu khóa 'info' bắt buộc")

        val infoSlice = rawBytes.copyOfRange(infoDict.rawStartIndex, infoDict.rawEndIndex)
        val sha1 = MessageDigest.getInstance("SHA-1").digest(infoSlice)
        val infoHashHex = sha1.joinToString("") { "%02x".format(it) }

        val name = (infoDict.entries["name.utf-8"] as? BValue.BBytes)?.asUtf8()
            ?: (infoDict.entries["name"] as? BValue.BBytes)?.asUtf8()
            ?: fallbackName

        val pieceLength = (infoDict.entries["piece length"] as? BValue.BInt)?.value ?: 262144L

        var totalSize = 0L
        var fileCount = 1
        val singleLength = (infoDict.entries["length"] as? BValue.BInt)?.value
        if (singleLength != null) {
            totalSize = singleLength
        } else {
            val filesList = (infoDict.entries["files"] as? BValue.BList)?.items.orEmpty()
            fileCount = filesList.size.coerceAtLeast(1)
            for (fileItem in filesList) {
                val fileDict = fileItem as? BValue.BDict ?: continue
                val len = (fileDict.entries["length"] as? BValue.BInt)?.value ?: 0L
                totalSize += len
            }
        }
        if (totalSize <= 0L) {
            totalSize = 1_073_741_824L // 1 GB fallback if magnet/meta only
        }

        val trackerSet = linkedSetOf<String>()
        (root.entries["announce"] as? BValue.BBytes)?.asUtf8()?.trim()?.takeIf { it.isNotEmpty() }?.let {
            trackerSet.add(it)
        }
        val announceList = (root.entries["announce-list"] as? BValue.BList)?.items.orEmpty()
        for (tier in announceList) {
            when (tier) {
                is BValue.BList -> {
                    for (item in tier.items) {
                        val url = (item as? BValue.BBytes)?.asUtf8()?.trim()
                        if (!url.isNullOrEmpty()) trackerSet.add(url)
                    }
                }
                is BValue.BBytes -> {
                    val url = tier.asUtf8().trim()
                    if (url.isNotEmpty()) trackerSet.add(url)
                }
                else -> {}
            }
        }

        if (trackerSet.isEmpty()) {
            trackerSet.add("udp://tracker.opentrackr.org:1337/announce")
            trackerSet.add("http://tracker.opentrackr.org:1337/announce")
        }

        val createdBy = (root.entries["created by"] as? BValue.BBytes)?.asUtf8() ?: "BitTorrent"
        val comment = (root.entries["comment"] as? BValue.BBytes)?.asUtf8() ?: ""

        return ParsedTorrentMeta(
            name = name,
            infoHashBytes = sha1,
            infoHashHex = infoHashHex,
            totalSize = totalSize,
            trackers = trackerSet.toList(),
            pieceLength = pieceLength,
            createdBy = createdBy,
            comment = comment,
            fileCount = fileCount
        )
    }

    /**
     * Giải mã phản hồi Bencode từ HTTP Tracker (lấy interval, complete/seeders, incomplete/leechers, failure reason).
     */
    fun decodeTrackerResponse(rawBytes: ByteArray): TrackerBencodeResponse {
        return try {
            val root = Cursor(rawBytes).readValue() as? BValue.BDict
                ?: return TrackerBencodeResponse(failureReason = "Phản hồi Tracker không đúng định dạng Bencode")

            val failure = (root.entries["failure reason"] as? BValue.BBytes)?.asUtf8()
            if (!failure.isNullOrEmpty()) {
                return TrackerBencodeResponse(failureReason = failure)
            }

            val interval = ((root.entries["interval"] as? BValue.BInt)?.value
                ?: (root.entries["min interval"] as? BValue.BInt)?.value
                ?: 1800L).toInt().coerceIn(60, 7200)

            var seeders = ((root.entries["complete"] as? BValue.BInt)?.value ?: 0L).toInt()
            var leechers = ((root.entries["incomplete"] as? BValue.BInt)?.value ?: 0L).toInt()

            val peersVal = root.entries["peers"]
            var peerCount = 0
            when (peersVal) {
                is BValue.BBytes -> peerCount = peersVal.bytes.size / 6
                is BValue.BList -> peerCount = peersVal.items.size
                else -> {}
            }
            if (seeders == 0 && peerCount > 0) {
                seeders = (peerCount * 0.7).toInt().coerceAtLeast(1)
                leechers = (peerCount - seeders).coerceAtLeast(1)
            }

            TrackerBencodeResponse(
                intervalSec = interval,
                seeders = seeders,
                leechers = leechers,
                failureReason = null
            )
        } catch (e: Exception) {
            TrackerBencodeResponse(failureReason = "Lỗi đọc Bencode: ${e.message}")
        }
    }

    /**
     * Tạo mảng byte tệp .torrent chuẩn Bencode hợp lệ để người dùng có thể tạo hoặc kiểm thử ngay trên thiết bị.
     */
    fun buildSyntheticTorrentBytes(
        name: String,
        sizeBytes: Long,
        trackers: List<String>,
        pieceLength: Long = 524288L,
        createdBy: String = "Seedr Ratio Engine"
    ): ByteArray {
        val primaryTracker = trackers.firstOrNull() ?: "udp://tracker.opentrackr.org:1337/announce"
        val out = ByteArrayOutputStream()

        fun writeBytes(str: String) {
            val b = str.toByteArray(StandardCharsets.UTF_8)
            out.write("${b.size}:".toByteArray(StandardCharsets.US_ASCII))
            out.write(b)
        }

        fun writeRawBytes(b: ByteArray) {
            out.write("${b.size}:".toByteArray(StandardCharsets.US_ASCII))
            out.write(b)
        }

        fun writeInt(v: Long) {
            out.write("i${v}e".toByteArray(StandardCharsets.US_ASCII))
        }

        out.write('d'.code)
        // announce
        writeBytes("announce")
        writeBytes(primaryTracker)

        // announce-list
        if (trackers.isNotEmpty()) {
            writeBytes("announce-list")
            out.write('l'.code)
            for (tr in trackers) {
                out.write('l'.code)
                writeBytes(tr)
                out.write('e'.code)
            }
            out.write('e'.code)
        }

        writeBytes("created by")
        writeBytes(createdBy)

        writeBytes("creation date")
        writeInt(System.currentTimeMillis() / 1000L)

        // info dictionary (sorted keys: length, name, piece length, pieces)
        writeBytes("info")
        out.write('d'.code)
        writeBytes("length")
        writeInt(sizeBytes)
        writeBytes("name")
        writeBytes(name)
        writeBytes("piece length")
        writeInt(pieceLength)
        writeBytes("pieces")
        val fakePieces = MessageDigest.getInstance("SHA-1")
            .digest("$name-$sizeBytes-$pieceLength".toByteArray(StandardCharsets.UTF_8))
        writeRawBytes(fakePieces)
        out.write('e'.code) // end info

        out.write('e'.code) // end root
        return out.toByteArray()
    }

    private class Cursor(private val data: ByteArray) {
        var pos: Int = 0

        fun readValue(): BValue {
            if (pos >= data.size) throw IllegalArgumentException("Unexpected EOF in Bencode")
            return when (val ch = data[pos].toInt().toChar()) {
                'i' -> readInt()
                'l' -> readList()
                'd' -> readDict()
                in '0'..'9' -> readBytes()
                else -> throw IllegalArgumentException("Ký tự Bencode không hợp lệ '$ch' tại vị trí $pos")
            }
        }

        private fun readInt(): BValue.BInt {
            pos++ // skip 'i'
            val end = indexOf('e'.code.toByte(), pos)
            if (end == -1) throw IllegalArgumentException("Thiếu 'e' kết thúc số nguyên Bencode")
            val numStr = String(data, pos, end - pos, StandardCharsets.US_ASCII)
            pos = end + 1
            return BValue.BInt(numStr.toLongOrNull() ?: 0L)
        }

        private fun readBytes(): BValue.BBytes {
            val colon = indexOf(':'.code.toByte(), pos)
            if (colon == -1) throw IllegalArgumentException("Thiếu ':' trong chuỗi Bencode")
            val lenStr = String(data, pos, colon - pos, StandardCharsets.US_ASCII)
            val len = lenStr.toIntOrNull() ?: throw IllegalArgumentException("Độ dài chuỗi không hợp lệ: $lenStr")
            pos = colon + 1
            if (pos + len > data.size) throw IllegalArgumentException("Độ dài chuỗi vượt quá kích thước tệp")
            val slice = data.copyOfRange(pos, pos + len)
            pos += len
            return BValue.BBytes(slice)
        }

        private fun readList(): BValue.BList {
            pos++ // skip 'l'
            val list = mutableListOf<BValue>()
            while (pos < data.size && data[pos].toInt().toChar() != 'e') {
                list.add(readValue())
            }
            if (pos < data.size && data[pos].toInt().toChar() == 'e') pos++
            return BValue.BList(list)
        }

        private fun readDict(): BValue.BDict {
            val startIdx = pos
            pos++ // skip 'd'
            val map = linkedMapOf<String, BValue>()
            while (pos < data.size && data[pos].toInt().toChar() != 'e') {
                val keyBytes = readBytes()
                val key = keyBytes.asUtf8()
                val value = readValue()
                map[key] = value
            }
            if (pos < data.size && data[pos].toInt().toChar() == 'e') pos++
            val endIdx = pos
            return BValue.BDict(map, rawStartIndex = startIdx, rawEndIndex = endIdx)
        }

        private fun indexOf(target: Byte, from: Int): Int {
            for (i in from until data.size) {
                if (data[i] == target) return i
            }
            return -1
        }
    }
}

data class TrackerBencodeResponse(
    val intervalSec: Int = 1800,
    val seeders: Int = 0,
    val leechers: Int = 0,
    val failureReason: String? = null
)
