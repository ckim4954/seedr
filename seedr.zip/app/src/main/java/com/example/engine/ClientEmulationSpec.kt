package com.example.engine

import com.example.data.ClientProfileEntity
import java.nio.charset.StandardCharsets
import kotlin.random.Random

/**
 * Thực thi quy tắc giả lập BitTorrent Client & Hệ điều hành (Operating System) chuẩn rursache/Seedr:
 * - Sinh peer_id đúng 20 byte theo tiền tố phiên bản và bảng mã ký tự
 * - Sinh khóa phiên (key) theo độ dài & định dạng Hex/Dec/Alphanumeric
 * - Dựng chuỗi User-Agent tích hợp thông tin Operating System (Windows, macOS, Linux, Android, Custom)
 * - Mã hóa phần trăm (URL-Encode) chính xác 20-byte nhị phân của info_hash và peer_id theo chữ hoa/thường
 */
object ClientEmulationSpec {

    private const val ALPHANUMERIC = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    private const val URL_SAFE_ASCII = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_.!~*()"
    private const val HEX_UPPER = "0123456789ABCDEF"
    private const val HEX_LOWER = "0123456789abcdef"
    private const val DECIMAL = "0123456789"

    data class OsPreset(
        val osFamily: String,
        val label: String,
        val osVersion: String,
        val osArch: String,
        val osToken: String
    )

    val osPresets: List<OsPreset> = listOf(
        OsPreset(
            osFamily = "Windows",
            label = "Windows 11 Pro 23H2 (64-bit)",
            osVersion = "Windows NT 10.0",
            osArch = "Win64; x64",
            osToken = "Windows NT 10.0; Win64; x64"
        ),
        OsPreset(
            osFamily = "Windows",
            label = "Windows 10 Enterprise LTSC (x64)",
            osVersion = "Windows NT 10.0",
            osArch = "Win64; x64",
            osToken = "Windows NT 10.0; Win64; x64; rv:128.0"
        ),
        OsPreset(
            osFamily = "Linux",
            label = "Ubuntu 24.04 LTS (Linux x86_64)",
            osVersion = "X11; Ubuntu; Linux",
            osArch = "x86_64",
            osToken = "X11; Ubuntu; Linux x86_64; Kernel 6.8.0-45-generic"
        ),
        OsPreset(
            osFamily = "Linux",
            label = "Debian 12 Bookworm Seedbox (x86_64)",
            osVersion = "X11; Debian; Linux",
            osArch = "x86_64",
            osToken = "X11; Linux x86_64; libtorrent/2.0.10.0"
        ),
        OsPreset(
            osFamily = "macOS",
            label = "macOS 15 Sequoia (Apple Silicon arm64)",
            osVersion = "Macintosh; Apple Silicon Mac OS X 15_0",
            osArch = "arm64",
            osToken = "Macintosh; Apple Silicon Mac OS X 15_0; arm64"
        ),
        OsPreset(
            osFamily = "macOS",
            label = "macOS 14 Sonoma (Intel x86_64)",
            osVersion = "Macintosh; Intel Mac OS X 14_5",
            osArch = "x86_64",
            osToken = "Macintosh; Intel Mac OS X 14_5_0"
        ),
        OsPreset(
            osFamily = "Android",
            label = "Android 15 Mobile (ARM64 Kernel)",
            osVersion = "Linux; Android 15",
            osArch = "arm64-v8a",
            osToken = "Linux; Android 15; Pixel 9 Pro Build/AP3A.241005.015"
        ),
        OsPreset(
            osFamily = "Custom",
            label = "Tùy chỉnh chuỗi Hệ điều hành (Custom OS/Kernel)",
            osVersion = "Custom OS",
            osArch = "x86_64",
            osToken = "FreeBSD 14.1-RELEASE-p5 amd64"
        )
    )

    fun resolveOsToken(profile: ClientProfileEntity): String {
        if (profile.customOsToken.isNotBlank()) {
            return profile.customOsToken.trim()
        }
        return "${profile.osVersion}; ${profile.osArch}".trim(' ', ';')
    }

    fun buildUserAgent(profile: ClientProfileEntity): String {
        val osToken = resolveOsToken(profile)
        val template = profile.userAgentTemplate.ifBlank { "${profile.clientFamily}/{version} ({os_token})" }
        return template
            .replace("{version}", profile.clientVersion)
            .replace("{os_token}", osToken)
            .replace("{os}", profile.osVersion)
            .replace("{arch}", profile.osArch)
    }

    fun generatePeerId(profile: ClientProfileEntity): String {
        val prefix = profile.peerIdPrefix.take(12)
        val remaining = (20 - prefix.length).coerceAtLeast(0)
        val pool = when (profile.peerIdCharset) {
            "HEX_LOWER" -> HEX_LOWER
            "HEX_UPPER" -> HEX_UPPER
            "URL_SAFE_ASCII" -> URL_SAFE_ASCII
            else -> ALPHANUMERIC
        }
        val sb = StringBuilder(20)
        sb.append(prefix)
        repeat(remaining) {
            sb.append(pool[Random.nextInt(pool.length)])
        }
        return sb.toString().take(20).padEnd(20, '0')
    }

    fun generateSessionKey(profile: ClientProfileEntity): String {
        val len = profile.keyLength.coerceIn(4, 16)
        val pool = when (profile.keyFormat) {
            "HEX_LOWER" -> HEX_LOWER
            "DECIMAL" -> DECIMAL
            "ALPHANUMERIC" -> ALPHANUMERIC
            else -> HEX_UPPER
        }
        return buildString(len) {
            repeat(len) {
                append(pool[Random.nextInt(pool.length)])
            }
        }
    }

    fun hexStringToBytes(hex: String): ByteArray {
        val clean = hex.trim()
        val len = clean.length
        val out = ByteArray(len / 2)
        var i = 0
        while (i < len) {
            val hi = Character.digit(clean[i], 16).coerceAtLeast(0)
            val lo = Character.digit(clean[i + 1], 16).coerceAtLeast(0)
            out[i / 2] = ((hi shl 4) + lo).toByte()
            i += 2
        }
        return out
    }

    /**
     * Mã hóa phần trăm mảng 20 byte nhị phân (info_hash hoặc peer_id) theo đúng chuẩn chữ hoa/thường của từng Client.
     */
    fun urlEncodeBinary(
        bytes: ByteArray,
        uppercaseHex: Boolean,
        encodeAllBytes: Boolean = false
    ): String {
        val sb = StringBuilder(bytes.size * 3)
        for (b in bytes) {
            val unsigned = b.toInt() and 0xFF
            val isUnreserved = (unsigned in 'a'.code..'z'.code) ||
                (unsigned in 'A'.code..'Z'.code) ||
                (unsigned in '0'.code..'9'.code) ||
                unsigned == '-'.code || unsigned == '_'.code ||
                unsigned == '.'.code || unsigned == '~'.code
            if (!encodeAllBytes && isUnreserved) {
                sb.append(unsigned.toChar())
            } else {
                val hex = if (uppercaseHex) "%02X".format(unsigned) else "%02x".format(unsigned)
                sb.append(hex)
            }
        }
        return sb.toString()
    }

    fun buildAnnounceUrl(
        baseTrackerUrl: String,
        profile: ClientProfileEntity,
        infoHashHex: String,
        peerId: String,
        key: String,
        uploaded: Long,
        downloaded: Long,
        left: Long,
        event: String?, // "started", "stopped", "completed", or null for periodic
        overridePort: Int? = null
    ): String {
        val uppercaseHex = profile.urlHexCase.equals("UPPER", ignoreCase = true)
        val infoHashBytes = hexStringToBytes(infoHashHex)
        val encodedInfoHash = urlEncodeBinary(
            bytes = infoHashBytes,
            uppercaseHex = uppercaseHex,
            encodeAllBytes = false
        )
        val peerIdBytes = peerId.toByteArray(StandardCharsets.ISO_8859_1)
        val encodedPeerId = urlEncodeBinary(
            bytes = peerIdBytes,
            uppercaseHex = uppercaseHex,
            encodeAllBytes = profile.peerIdUrlEncodeAll
        )
        val port = overridePort ?: profile.emulatedPort
        val eventParam = if (!event.isNullOrBlank()) "&event=$event" else ""

        val query = profile.queryTemplate
            .replace("{info_hash}", encodedInfoHash)
            .replace("{peer_id}", encodedPeerId)
            .replace("{port}", port.toString())
            .replace("{uploaded}", uploaded.toString())
            .replace("{downloaded}", downloaded.toString())
            .replace("{left}", left.toString())
            .replace("{key}", key)
            .replace("{numwant}", profile.numWant.toString())
            .replace("{event_param}", eventParam)

        val separator = if (baseTrackerUrl.contains("?")) "&" else "?"
        return "$baseTrackerUrl$separator$query"
    }

    fun parseCustomHeaders(profile: ClientProfileEntity): List<Pair<String, String>> {
        val result = mutableListOf<Pair<String, String>>()
        result.add("User-Agent" to buildUserAgent(profile))
        profile.customHeadersCsv.split("\n").forEach { line ->
            val idx = line.indexOf(':')
            if (idx > 0) {
                val k = line.substring(0, idx).trim()
                val v = line.substring(idx + 1).trim()
                if (k.isNotEmpty() && !k.equals("User-Agent", ignoreCase = true)) {
                    result.add(k to v)
                }
            }
        }
        return result
    }
}
