package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.outlined.Computer
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.NetworkCheck
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.FormatUtils
import com.example.ui.SeedrViewModel
import com.example.ui.screens.ClientProfileStudioScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.EventLogsScreen
import com.example.ui.screens.NetworkToolsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.ProtocolCyan
import com.example.ui.theme.SignalEmerald
import com.example.ui.theme.SlateSurface
import com.example.ui.theme.SlateSurfaceElevated
import com.example.ui.theme.TextSecondary

enum class SeedrDestination(
    val route: String,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    DASHBOARD("dashboard", "Seeding", Icons.Filled.Speed, Icons.Outlined.Speed),
    PROFILES("profiles", "Client & OS", Icons.Filled.Computer, Icons.Outlined.Computer),
    LOGS("logs", "Nhật ký", Icons.Filled.History, Icons.Outlined.History),
    NETWORK("network", "Công cụ Mạng", Icons.Filled.NetworkCheck, Icons.Outlined.NetworkCheck)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                SeedrAppRoot()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SeedrAppRoot(
    seedrViewModel: SeedrViewModel = viewModel()
) {
    val dashboardState by seedrViewModel.dashboardState.collectAsStateWithLifecycle()
    val torrents by seedrViewModel.torrents.collectAsStateWithLifecycle()
    val profiles by seedrViewModel.profiles.collectAsStateWithLifecycle()
    val selectedProfile by seedrViewModel.selectedProfile.collectAsStateWithLifecycle()
    val eventLogs by seedrViewModel.eventLogs.collectAsStateWithLifecycle()
    val globalSettings by seedrViewModel.globalSettings.collectAsStateWithLifecycle()

    var currentTab by rememberSaveable { mutableStateOf(SeedrDestination.DASHBOARD) }

    // Hỗ trợ nút Back hệ thống quay về tab Seeding chính khi đang ở các tab phụ
    if (currentTab != SeedrDestination.DASHBOARD) {
        BackHandler {
            currentTab = SeedrDestination.DASHBOARD
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isExpandedScreen = maxWidth >= 700.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            contentWindowInsets = WindowInsets.safeDrawing,
            containerColor = ObsidianBackground,
            topBar = {
                TopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Column {
                                Text(
                                    text = "Seedr Ratio Engine",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = selectedProfile?.let {
                                        "${it.clientFamily} ${it.clientVersion} • ${it.osFamily}"
                                    } ?: "BitTorrent Tracker Protocol Simulator",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ProtocolCyan
                                )
                            }
                        }
                    },
                    actions = {
                        Surface(
                            color = if (dashboardState.isEngineRunning) {
                                SignalEmerald.copy(alpha = 0.16f)
                            } else {
                                SlateSurfaceElevated
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .padding(end = 12.dp)
                                .clickable { seedrViewModel.toggleEngine() }
                                .testTag("topbar_speed_pill")
                        ) {
                            Text(
                                text = if (dashboardState.isEngineRunning) {
                                    "↑ ${FormatUtils.formatSpeed(dashboardState.totalUploadSpeedBps)}"
                                } else {
                                    "PAUSED"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = if (dashboardState.isEngineRunning) SignalEmerald else TextSecondary,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = SlateSurface
                    )
                )
            },
            bottomBar = {
                if (!isExpandedScreen) {
                    NavigationBar(
                        containerColor = SlateSurface,
                        tonalElevation = 8.dp
                    ) {
                        SeedrDestination.entries.forEach { dest ->
                            val selected = currentTab == dest
                            NavigationBarItem(
                                selected = selected,
                                onClick = { currentTab = dest },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = dest.title
                                    )
                                },
                                label = {
                                    Text(
                                        text = dest.title,
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = SignalEmerald,
                                    selectedTextColor = SignalEmerald,
                                    indicatorColor = SignalEmerald.copy(alpha = 0.16f),
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                ),
                                modifier = Modifier.testTag("nav_tab_${dest.route}")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (isExpandedScreen) {
                    NavigationRail(
                        containerColor = SlateSurface,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        SeedrDestination.entries.forEach { dest ->
                            val selected = currentTab == dest
                            NavigationRailItem(
                                selected = selected,
                                onClick = { currentTab = dest },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = dest.title
                                    )
                                },
                                label = { Text(dest.title) },
                                modifier = Modifier.testTag("rail_tab_${dest.route}")
                            )
                        }
                    }
                }

                Column(modifier = Modifier.fillMaxSize()) {
                    // Thanh thông báo trạng thái nhanh
                    AnimatedVisibility(visible = dashboardState.statusBannerMessage != null) {
                        val msg = dashboardState.statusBannerMessage.orEmpty()
                        Surface(
                            color = SlateSurfaceElevated,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = msg,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SignalEmerald,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = { seedrViewModel.clearStatusBanner() },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Đóng thông báo",
                                        tint = TextSecondary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }

                    Box(modifier = Modifier.fillMaxSize()) {
                        when (currentTab) {
                            SeedrDestination.DASHBOARD -> {
                                DashboardScreen(
                                    dashboardState = dashboardState,
                                    torrents = torrents,
                                    selectedProfile = selectedProfile,
                                    globalSettings = globalSettings,
                                    onToggleEngine = seedrViewModel::toggleEngine,
                                    onForceAnnounceAll = seedrViewModel::forceAnnounceAllActive,
                                    onPickTorrentUri = seedrViewModel::parseTorrentFromUri,
                                    onCreateSyntheticTorrent = seedrViewModel::createAndPreviewSyntheticTorrent,
                                    onConfirmParsedTorrent = seedrViewModel::confirmAddParsedTorrent,
                                    onDismissParsedTorrent = seedrViewModel::dismissPendingTorrent,
                                    onToggleTorrent = seedrViewModel::toggleTorrentActive,
                                    onForceAnnounceTorrent = seedrViewModel::forceAnnounceTorrent,
                                    onSwitchTracker = seedrViewModel::switchActiveTracker,
                                    onUpdateTargetRatio = seedrViewModel::updateTorrentTargetRatio,
                                    onDeleteTorrent = seedrViewModel::deleteTorrent,
                                    onOpenProfileStudio = { currentTab = SeedrDestination.PROFILES }
                                )
                            }

                            SeedrDestination.PROFILES -> {
                                ClientProfileStudioScreen(
                                    profiles = profiles,
                                    selectedProfile = selectedProfile,
                                    onSelectProfile = seedrViewModel::selectClientProfile,
                                    onSaveProfile = { profile ->
                                        seedrViewModel.saveClientProfile(profile, selectImmediately = true)
                                    },
                                    onDeleteCustomProfile = seedrViewModel::deleteCustomProfile
                                )
                            }

                            SeedrDestination.LOGS -> {
                                EventLogsScreen(
                                    logs = eventLogs,
                                    onClearLogs = seedrViewModel::clearEventLogs
                                )
                            }

                            SeedrDestination.NETWORK -> {
                                NetworkToolsScreen(
                                    globalSettings = globalSettings,
                                    isCheckingPort = dashboardState.isCheckingPort,
                                    lastPortReport = dashboardState.lastPortReport,
                                    onRunPortCheck = seedrViewModel::runPortCheck,
                                    onSaveGlobalSettings = seedrViewModel::updateGlobalSettings
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
