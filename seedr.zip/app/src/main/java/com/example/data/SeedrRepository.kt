package com.example.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.seedrDataStore by preferencesDataStore(name = "seedr_global_settings")

class SeedrRepository(
    private val context: Context,
    private val dao: SeedrDao
) {
    private object Keys {
        val MIN_UPLOAD_KBPS = intPreferencesKey("min_upload_kbps")
        val MAX_UPLOAD_KBPS = intPreferencesKey("max_upload_kbps")
        val JITTER_PERCENT = intPreferencesKey("jitter_percent")
        val DEFAULT_TARGET_RATIO = doublePreferencesKey("default_target_ratio")
        val SIMULTANEOUS_LIMIT = intPreferencesKey("simultaneous_seed_limit")
        val EMULATED_PORT = intPreferencesKey("emulated_listen_port")
        val AUTO_FAILOVER = booleanPreferencesKey("auto_failover_trackers")
        val KEEP_ZERO_LEECHES = booleanPreferencesKey("keep_zero_leeches_seeding")
    }

    val torrentsFlow: Flow<List<TorrentEntity>> = dao.observeAllTorrents()
    val profilesFlow: Flow<List<ClientProfileEntity>> = dao.observeAllProfiles()
    val selectedProfileFlow: Flow<ClientProfileEntity?> = dao.observeSelectedProfile()
    val recentLogsFlow: Flow<List<EventLogEntity>> = dao.observeRecentLogs()

    val globalSettingsFlow: Flow<GlobalEngineSettings> = context.seedrDataStore.data.map { prefs ->
        GlobalEngineSettings(
            minUploadRateKbps = prefs[Keys.MIN_UPLOAD_KBPS] ?: 450,
            maxUploadRateKbps = prefs[Keys.MAX_UPLOAD_KBPS] ?: 3200,
            jitterPercent = prefs[Keys.JITTER_PERCENT] ?: 18,
            defaultTargetRatio = prefs[Keys.DEFAULT_TARGET_RATIO] ?: 3.0,
            simultaneousSeedLimit = prefs[Keys.SIMULTANEOUS_LIMIT] ?: 5,
            emulatedListenPort = prefs[Keys.EMULATED_PORT] ?: 51413,
            autoFailoverTrackers = prefs[Keys.AUTO_FAILOVER] ?: true,
            keepZeroLeechesSeeding = prefs[Keys.KEEP_ZERO_LEECHES] ?: true
        )
    }

    suspend fun ensureSeedDataInitialized() {
        val existingProfiles = dao.getAllProfilesOnce()
        if (existingProfiles.isEmpty()) {
            dao.insertProfiles(SeedrDatabase.defaultClientProfiles())
            val samples = SeedrDatabase.defaultSampleTorrents()
            for (torrent in samples) {
                dao.insertTorrent(torrent)
            }
            dao.insertLog(
                EventLogEntity(
                    eventType = "PROFILE",
                    torrentName = "Hệ thống",
                    trackerUrl = "Local SQLite Engine",
                    protocol = "SYSTEM",
                    details = "Đã khởi tạo 5 hồ sơ BitTorrent Client & OS chuẩn cùng bộ giải mã Bencode/BEP-15."
                )
            )
        }
    }

    suspend fun updateGlobalSettings(settings: GlobalEngineSettings) {
        context.seedrDataStore.edit { prefs ->
            prefs[Keys.MIN_UPLOAD_KBPS] = settings.minUploadRateKbps.coerceIn(10, 50_000)
            prefs[Keys.MAX_UPLOAD_KBPS] = settings.maxUploadRateKbps.coerceAtLeast(settings.minUploadRateKbps + 10)
            prefs[Keys.JITTER_PERCENT] = settings.jitterPercent.coerceIn(1, 80)
            prefs[Keys.DEFAULT_TARGET_RATIO] = settings.defaultTargetRatio.coerceIn(0.1, 100.0)
            prefs[Keys.SIMULTANEOUS_LIMIT] = settings.simultaneousSeedLimit.coerceIn(1, 30)
            prefs[Keys.EMULATED_PORT] = settings.emulatedListenPort.coerceIn(1024, 65535)
            prefs[Keys.AUTO_FAILOVER] = settings.autoFailoverTrackers
            prefs[Keys.KEEP_ZERO_LEECHES] = settings.keepZeroLeechesSeeding
        }
    }

    suspend fun getAllTorrentsOnce(): List<TorrentEntity> = dao.getAllTorrentsOnce()
    suspend fun getTorrentById(id: Long): TorrentEntity? = dao.getTorrentById(id)
    suspend fun insertTorrent(torrent: TorrentEntity): Long = dao.insertTorrent(torrent)
    suspend fun updateTorrent(torrent: TorrentEntity) = dao.updateTorrent(torrent)
    suspend fun deleteTorrent(torrent: TorrentEntity) = dao.deleteTorrent(torrent)
    suspend fun resetAllSpeeds() = dao.resetAllSpeeds()

    suspend fun getSelectedProfileOnce(): ClientProfileEntity =
        dao.getSelectedProfileOnce() ?: SeedrDatabase.defaultClientProfiles().first()

    suspend fun selectProfile(profileId: Long) = dao.selectProfileById(profileId)
    suspend fun saveProfile(profile: ClientProfileEntity): Long = dao.insertProfile(profile)
    suspend fun deleteCustomProfile(profileId: Long) = dao.deleteCustomProfile(profileId)

    suspend fun logEvent(log: EventLogEntity) = dao.insertLog(log)
    suspend fun clearLogs() = dao.clearAllLogs()
}
