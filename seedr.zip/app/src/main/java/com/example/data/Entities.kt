package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "torrents")
data class TorrentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val infoHashHex: String,
    val totalSize: Long,
    val trackersCsv: String,
    val activeTrackerIndex: Int = 0,
    val uploadedBytes: Long = 0L,
    val downloadedBytes: Long = 0L,
    val leftBytes: Long = 0L,
    val currentSpeedBps: Long = 0L,
    val seeders: Int = 18,
    val leechers: Int = 6,
    val announceIntervalSec: Int = 1800,
    val nextAnnounceEpochSec: Long = 0L,
    val lastAnnounceEpochSec: Long = 0L,
    val lastAnnounceStatus: String = "Sẵn sàng",
    val isActive: Boolean = true,
    val targetRatio: Double = 3.0,
    val hasSentStarted: Boolean = false,
    val sessionPeerId: String = "",
    val sessionKey: String = "",
    val addedAt: Long = System.currentTimeMillis()
) {
    fun trackerList(): List<String> =
        trackersCsv.split("\n").map { it.trim() }.filter { it.isNotEmpty() }

    fun currentTrackerUrl(): String {
        val list = trackerList()
        if (list.isEmpty()) return "udp://tracker.opentrackr.org:1337/announce"
        return list[activeTrackerIndex.coerceIn(0, list.lastIndex)]
    }

    fun currentRatio(): Double {
        if (totalSize <= 0L) return 0.0
        return uploadedBytes.toDouble() / totalSize.toDouble()
    }
}

@Entity(tableName = "client_profiles")
data class ClientProfileEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val clientFamily: String, // qBittorrent, Deluge, Transmission, uTorrent, BitTorrent, Custom
    val clientVersion: String,
    val osFamily: String, // Windows, macOS, Linux, Android, Custom
    val osVersion: String, // e.g., Windows NT 10.0, Mac OS X 14_5, Linux x86_64, Android 15
    val osArch: String, // Win64; x64, arm64, x86_64
    val customOsToken: String = "", // Optional full custom OS string inside User-Agent
    val userAgentTemplate: String, // Supports {version}, {os_token}, {arch}, {build}
    val peerIdPrefix: String, // e.g., -qB4650-, -DE211s-, -TR4060-, -UT355W-, -BT7a50-
    val peerIdRandomLength: Int = 12,
    val peerIdCharset: String = "ALPHANUMERIC", // ALPHANUMERIC, URL_SAFE_ASCII, HEX_LOWER, HEX_UPPER
    val peerIdUrlEncodeAll: Boolean = false,
    val keyLength: Int = 8,
    val keyFormat: String = "HEX_UPPER", // HEX_UPPER, HEX_LOWER, DECIMAL, ALPHANUMERIC
    val urlHexCase: String = "UPPER", // UPPER (%2F) or LOWER (%2f)
    val numWant: Int = 200,
    val emulatedPort: Int = 51413,
    val queryTemplate: String, // Exact query parameter order
    val customHeadersCsv: String, // e.g., Accept-Encoding: gzip\nConnection: close
    val supportCompact: Boolean = true,
    val supportCrypto: Boolean = true,
    val isSelected: Boolean = false,
    val isBuiltIn: Boolean = false
)

@Entity(tableName = "event_logs")
data class EventLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val timestamp: Long = System.currentTimeMillis(),
    val eventType: String, // STARTED, ANNOUNCE, STOPPED, FAILOVER, RATIO_REACHED, PORT_CHECK, ERROR, PROFILE
    val torrentName: String,
    val trackerUrl: String,
    val uploadedDeltaBytes: Long = 0L,
    val seeders: Int = 0,
    val leechers: Int = 0,
    val protocol: String = "HTTP", // HTTP, HTTPS, UDP BEP-15, SYSTEM
    val details: String
)

data class GlobalEngineSettings(
    val minUploadRateKbps: Int = 450,
    val maxUploadRateKbps: Int = 3200,
    val jitterPercent: Int = 18,
    val defaultTargetRatio: Double = 3.0,
    val simultaneousSeedLimit: Int = 5,
    val emulatedListenPort: Int = 51413,
    val autoFailoverTrackers: Boolean = true,
    val keepZeroLeechesSeeding: Boolean = true
)
