package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SeedrDao {

    // --- Torrents ---
    @Query("SELECT * FROM torrents ORDER BY addedAt DESC")
    fun observeAllTorrents(): Flow<List<TorrentEntity>>

    @Query("SELECT * FROM torrents ORDER BY addedAt DESC")
    suspend fun getAllTorrentsOnce(): List<TorrentEntity>

    @Query("SELECT * FROM torrents WHERE id = :id LIMIT 1")
    suspend fun getTorrentById(id: Long): TorrentEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTorrent(torrent: TorrentEntity): Long

    @Update
    suspend fun updateTorrent(torrent: TorrentEntity)

    @Delete
    suspend fun deleteTorrent(torrent: TorrentEntity)

    @Query("UPDATE torrents SET currentSpeedBps = 0")
    suspend fun resetAllSpeeds()

    // --- Client & OS Profiles ---
    @Query("SELECT * FROM client_profiles ORDER BY isBuiltIn DESC, id ASC")
    fun observeAllProfiles(): Flow<List<ClientProfileEntity>>

    @Query("SELECT * FROM client_profiles ORDER BY isBuiltIn DESC, id ASC")
    suspend fun getAllProfilesOnce(): List<ClientProfileEntity>

    @Query("SELECT * FROM client_profiles WHERE isSelected = 1 LIMIT 1")
    fun observeSelectedProfile(): Flow<ClientProfileEntity?>

    @Query("SELECT * FROM client_profiles WHERE isSelected = 1 LIMIT 1")
    suspend fun getSelectedProfileOnce(): ClientProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: ClientProfileEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfiles(profiles: List<ClientProfileEntity>)

    @Update
    suspend fun updateProfile(profile: ClientProfileEntity)

    @Query("UPDATE client_profiles SET isSelected = CASE WHEN id = :profileId THEN 1 ELSE 0 END")
    suspend fun selectProfileById(profileId: Long)

    @Query("DELETE FROM client_profiles WHERE id = :profileId AND isBuiltIn = 0")
    suspend fun deleteCustomProfile(profileId: Long)

    // --- Event Logs ---
    @Query("SELECT * FROM event_logs ORDER BY timestamp DESC LIMIT 250")
    fun observeRecentLogs(): Flow<List<EventLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: EventLogEntity)

    @Query("DELETE FROM event_logs")
    suspend fun clearAllLogs()
}
