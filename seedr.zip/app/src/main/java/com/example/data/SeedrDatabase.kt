package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.engine.BencodeParser

@Database(
    entities = [
        TorrentEntity::class,
        ClientProfileEntity::class,
        EventLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SeedrDatabase : RoomDatabase() {
    abstract fun seedrDao(): SeedrDao

    companion object {
        @Volatile
        private var INSTANCE: SeedrDatabase? = null

        fun getInstance(context: Context): SeedrDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SeedrDatabase::class.java,
                    "seedr_ratio_engine.db"
                ).build()
                INSTANCE = instance
                instance
            }
        }

        fun defaultClientProfiles(): List<ClientProfileEntity> = listOf(
            ClientProfileEntity(
                name = "qBittorrent 4.6.5 (Windows 11 x64)",
                clientFamily = "qBittorrent",
                clientVersion = "4.6.5",
                osFamily = "Windows",
                osVersion = "Windows NT 10.0",
                osArch = "Win64; x64",
                customOsToken = "Windows NT 10.0; Win64; x64",
                userAgentTemplate = "qBittorrent/{version} ({os_token})",
                peerIdPrefix = "-qB4650-",
                peerIdRandomLength = 12,
                peerIdCharset = "URL_SAFE_ASCII",
                peerIdUrlEncodeAll = false,
                keyLength = 8,
                keyFormat = "HEX_UPPER",
                urlHexCase = "LOWER",
                numWant = 200,
                emulatedPort = 54832,
                queryTemplate = "info_hash={info_hash}&peer_id={peer_id}&port={port}&uploaded={uploaded}&downloaded={downloaded}&left={left}&corrupt=0&key={key}{event_param}&numwant={numwant}&compact=1&no_peer_id=1&supportcrypto=1&redundant=0",
                customHeadersCsv = "Accept-Encoding: gzip\nConnection: close",
                supportCompact = true,
                supportCrypto = true,
                isSelected = true,
                isBuiltIn = true
            ),
            ClientProfileEntity(
                name = "Deluge 2.1.1 (Ubuntu Linux x86_64)",
                clientFamily = "Deluge",
                clientVersion = "2.1.1",
                osFamily = "Linux",
                osVersion = "X11; Ubuntu; Linux",
                osArch = "x86_64",
                customOsToken = "X11; Ubuntu; Linux x86_64; libtorrent/2.0.9.0",
                userAgentTemplate = "Deluge/{version} ({os_token})",
                peerIdPrefix = "-DE211s-",
                peerIdRandomLength = 12,
                peerIdCharset = "ALPHANUMERIC",
                peerIdUrlEncodeAll = false,
                keyLength = 8,
                keyFormat = "HEX_UPPER",
                urlHexCase = "UPPER",
                numWant = 200,
                emulatedPort = 58846,
                queryTemplate = "info_hash={info_hash}&peer_id={peer_id}&port={port}&uploaded={uploaded}&downloaded={downloaded}&left={left}{event_param}&key={key}&compact=1&numwant={numwant}&supportcrypto=1&no_peer_id=1",
                customHeadersCsv = "Accept-Encoding: gzip\nConnection: close",
                supportCompact = true,
                supportCrypto = true,
                isSelected = false,
                isBuiltIn = true
            ),
            ClientProfileEntity(
                name = "Transmission 4.0.6 (macOS Sonoma arm64)",
                clientFamily = "Transmission",
                clientVersion = "4.0.6",
                osFamily = "macOS",
                osVersion = "Macintosh; Apple Silicon Mac OS X 14_5",
                osArch = "arm64",
                customOsToken = "Macintosh; Apple Silicon Mac OS X 14_5; arm64",
                userAgentTemplate = "Transmission/{version} ({os_token})",
                peerIdPrefix = "-TR4060-",
                peerIdRandomLength = 12,
                peerIdCharset = "ALPHANUMERIC",
                peerIdUrlEncodeAll = false,
                keyLength = 8,
                keyFormat = "HEX_LOWER",
                urlHexCase = "LOWER",
                numWant = 80,
                emulatedPort = 51413,
                queryTemplate = "info_hash={info_hash}&peer_id={peer_id}&port={port}&uploaded={uploaded}&downloaded={downloaded}&left={left}&numwant={numwant}&key={key}&compact=1&supportcrypto=1{event_param}",
                customHeadersCsv = "Accept: */*\nAccept-Encoding: gzip;q=1.0, deflate, identity",
                supportCompact = true,
                supportCrypto = true,
                isSelected = false,
                isBuiltIn = true
            ),
            ClientProfileEntity(
                name = "uTorrent 3.5.5 (Windows 10 x64 Build 46392)",
                clientFamily = "uTorrent",
                clientVersion = "3.5.5",
                osFamily = "Windows",
                osVersion = "Windows NT 10.0",
                osArch = "Win64; x64",
                customOsToken = "Windows NT 10.0; Win64; x64; Build 46392",
                userAgentTemplate = "uTorrent/355B({os_token})",
                peerIdPrefix = "-UT355W-",
                peerIdRandomLength = 12,
                peerIdCharset = "HEX_LOWER",
                peerIdUrlEncodeAll = true,
                keyLength = 8,
                keyFormat = "HEX_UPPER",
                urlHexCase = "UPPER",
                numWant = 200,
                emulatedPort = 49160,
                queryTemplate = "info_hash={info_hash}&peer_id={peer_id}&port={port}&uploaded={uploaded}&downloaded={downloaded}&left={left}&corrupt=0&key={key}{event_param}&numwant={numwant}&compact=1&no_peer_id=1",
                customHeadersCsv = "Accept-Encoding: gzip\nConnection: Close",
                supportCompact = true,
                supportCrypto = true,
                isSelected = false,
                isBuiltIn = true
            ),
            ClientProfileEntity(
                name = "BitTorrent 7.10.5 (Windows 11 x64)",
                clientFamily = "BitTorrent",
                clientVersion = "7.10.5",
                osFamily = "Windows",
                osVersion = "Windows NT 10.0",
                osArch = "Win64; x64",
                customOsToken = "Windows NT 10.0; Win64; x64",
                userAgentTemplate = "BitTorrent/7105({os_token})",
                peerIdPrefix = "-BT7a50-",
                peerIdRandomLength = 12,
                peerIdCharset = "HEX_UPPER",
                peerIdUrlEncodeAll = true,
                keyLength = 8,
                keyFormat = "HEX_UPPER",
                urlHexCase = "UPPER",
                numWant = 200,
                emulatedPort = 6881,
                queryTemplate = "info_hash={info_hash}&peer_id={peer_id}&port={port}&uploaded={uploaded}&downloaded={downloaded}&left={left}&corrupt=0&key={key}{event_param}&numwant={numwant}&compact=1&no_peer_id=1",
                customHeadersCsv = "Accept-Encoding: gzip\nConnection: Close",
                supportCompact = true,
                supportCrypto = true,
                isSelected = false,
                isBuiltIn = true
            )
        )

        fun defaultSampleTorrents(): List<TorrentEntity> {
            val sample1Bytes = BencodeParser.buildSyntheticTorrentBytes(
                name = "ubuntu-24.04.1-desktop-amd64.iso",
                sizeBytes = 5_124_833_280L, // ~4.77 GB
                trackers = listOf(
                    "https://torrent.ubuntu.com/announce",
                    "udp://tracker.opentrackr.org:1337/announce",
                    "http://tracker.opentrackr.org:1337/announce"
                )
            )
            val meta1 = BencodeParser.parseTorrentFile(sample1Bytes)

            val sample2Bytes = BencodeParser.buildSyntheticTorrentBytes(
                name = "debian-12.7.0-amd64-DVD-1.iso",
                sizeBytes = 3_992_977_408L, // ~3.72 GB
                trackers = listOf(
                    "http://bttracker.debian.org:6969/announce",
                    "udp://tracker.openbittorrent.com:6969/announce",
                    "udp://exodus.desync.com:6969/announce"
                )
            )
            val meta2 = BencodeParser.parseTorrentFile(sample2Bytes)

            val nowSec = System.currentTimeMillis() / 1000L
            return listOf(
                TorrentEntity(
                    name = meta1.name,
                    infoHashHex = meta1.infoHashHex,
                    totalSize = meta1.totalSize,
                    trackersCsv = meta1.trackers.joinToString("\n"),
                    activeTrackerIndex = 0,
                    uploadedBytes = 3_482_120_192L,
                    downloadedBytes = 0L,
                    leftBytes = 0L,
                    currentSpeedBps = 0L,
                    seeders = 142,
                    leechers = 29,
                    announceIntervalSec = 1800,
                    nextAnnounceEpochSec = nowSec + 420L,
                    lastAnnounceEpochSec = nowSec - 1380L,
                    lastAnnounceStatus = "200 OK (142S / 29L)",
                    isActive = true,
                    targetRatio = 3.0,
                    hasSentStarted = true
                ),
                TorrentEntity(
                    name = meta2.name,
                    infoHashHex = meta2.infoHashHex,
                    totalSize = meta2.totalSize,
                    trackersCsv = meta2.trackers.joinToString("\n"),
                    activeTrackerIndex = 0,
                    uploadedBytes = 1_195_376_640L,
                    downloadedBytes = 0L,
                    leftBytes = 0L,
                    currentSpeedBps = 0L,
                    seeders = 86,
                    leechers = 14,
                    announceIntervalSec = 1800,
                    nextAnnounceEpochSec = nowSec + 750L,
                    lastAnnounceEpochSec = nowSec - 1050L,
                    lastAnnounceStatus = "BEP-15 OK (86S / 14L)",
                    isActive = true,
                    targetRatio = 2.5,
                    hasSentStarted = true
                )
            )
        }
    }
}
